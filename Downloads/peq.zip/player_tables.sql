/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_timers` (
  `charid` int(12) unsigned NOT NULL DEFAULT '0',
  `ability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `begin` int(10) unsigned NOT NULL DEFAULT '0',
  `end` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`ability`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `sharedplat` int(11) unsigned NOT NULL DEFAULT '0',
  `password` varchar(50) NOT NULL DEFAULT '',
  `status` int(5) NOT NULL DEFAULT '0',
  `lsaccount_id` int(11) unsigned DEFAULT NULL,
  `gmspeed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `revoked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `karma` int(5) unsigned NOT NULL DEFAULT '0',
  `minilogin_ip` varchar(32) NOT NULL DEFAULT '',
  `hideme` tinyint(4) NOT NULL DEFAULT '0',
  `rulesflag` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `suspendeduntil` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_creation` int(10) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `lsaccount_id` (`lsaccount_id`)
) ENGINE=MyISAM AUTO_INCREMENT=67475 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_flags` (
  `p_accid` int(10) unsigned NOT NULL,
  `p_flag` varchar(50) NOT NULL,
  `p_value` varchar(80) NOT NULL,
  PRIMARY KEY (`p_accid`,`p_flag`),
  KEY `p_accid` (`p_accid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_ip` (
  `accid` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(32) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '1',
  `lastused` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `ip` (`accid`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_rewards` (
  `account_id` int(10) unsigned NOT NULL,
  `reward_id` int(10) unsigned NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  UNIQUE KEY `account_reward` (`account_id`,`reward_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adventure_id` smallint(5) unsigned NOT NULL,
  `instance_id` int(11) NOT NULL DEFAULT '-1',
  `count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `assassinate_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time_created` int(10) unsigned NOT NULL DEFAULT '0',
  `time_zoned` int(10) unsigned NOT NULL DEFAULT '0',
  `time_completed` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1798 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_members` (
  `id` int(10) unsigned NOT NULL,
  `charid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`charid`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_stats` (
  `player_id` int(10) unsigned NOT NULL,
  `guk_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mir_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mmc_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ruj_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tak_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guk_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mir_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mmc_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ruj_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tak_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  UNIQUE KEY `player_id` (`player_id`),
  KEY `player_id_2` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Banned_IPs` (
  `ip_address` varchar(20) NOT NULL DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bugs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `zone` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ui` varchar(128) NOT NULL,
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `type` varchar(64) NOT NULL,
  `flag` tinyint(3) unsigned NOT NULL,
  `target` varchar(64) DEFAULT NULL,
  `bug` varchar(1024) NOT NULL,
  `date` date NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=704 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyer` (
  `charid` int(11) NOT NULL DEFAULT '0',
  `buyslot` int(11) NOT NULL DEFAULT '0',
  `itemid` int(11) NOT NULL DEFAULT '0',
  `itemname` varchar(65) NOT NULL DEFAULT '',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`buyslot`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `char_recipe_list` (
  `char_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `madecount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`recipe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `profile` blob,
  `timelaston` int(11) unsigned DEFAULT '0',
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `zonename` varchar(30) NOT NULL DEFAULT '',
  `alt_adv` blob,
  `zoneid` smallint(6) NOT NULL DEFAULT '0',
  `instanceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pktime` int(8) NOT NULL DEFAULT '0',
  `inventory` blob,
  `groupid` int(10) unsigned NOT NULL DEFAULT '0',
  `extprofile` blob,
  `class` tinyint(4) NOT NULL DEFAULT '0',
  `level` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lfp` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lfg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `mailkey` varchar(16) DEFAULT '0',
  `xtargets` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `firstlogon` tinyint(3) NOT NULL DEFAULT '0',
  `inspectmessage` varchar(256) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=170454 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_activities` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  `activityid` int(11) unsigned NOT NULL DEFAULT '0',
  `donecount` int(11) unsigned NOT NULL DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`charid`,`taskid`,`activityid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_alt_currency` (
  `char_id` int(10) unsigned NOT NULL,
  `currency_id` int(10) unsigned NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  PRIMARY KEY (`char_id`,`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_backup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `backupreason` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `account_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `profile` blob,
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `zoneid` smallint(5) NOT NULL DEFAULT '0',
  `alt_adv` blob,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `class` tinyint(4) NOT NULL DEFAULT '0',
  `level` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `charid` (`charid`)
) ENGINE=MyISAM AUTO_INCREMENT=11362777 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_buffs` (
  `character_id` int(10) unsigned NOT NULL,
  `slot_id` tinyint(3) unsigned NOT NULL,
  `spell_id` smallint(10) unsigned NOT NULL,
  `caster_level` tinyint(3) unsigned NOT NULL,
  `caster_name` varchar(64) NOT NULL,
  `ticsremaining` int(10) unsigned NOT NULL,
  `counters` int(10) unsigned NOT NULL,
  `numhits` int(10) unsigned NOT NULL,
  `melee_rune` int(10) unsigned NOT NULL,
  `magic_rune` int(10) unsigned NOT NULL,
  `persistent` tinyint(3) unsigned NOT NULL,
  `dot_rune` int(10) NOT NULL DEFAULT '0',
  `caston_x` int(10) NOT NULL DEFAULT '0',
  `caston_y` int(10) NOT NULL DEFAULT '0',
  `caston_z` int(10) NOT NULL DEFAULT '0',
  `ExtraDIChance` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`character_id`,`slot_id`),
  KEY `character_id` (`character_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_enabledtasks` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`taskid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_buffs` (
  `char_id` int(11) NOT NULL,
  `pet` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `spell_id` int(11) NOT NULL,
  `caster_level` tinyint(4) NOT NULL DEFAULT '0',
  `castername` varchar(64) NOT NULL DEFAULT '',
  `ticsremaining` int(11) NOT NULL DEFAULT '0',
  `counters` int(11) NOT NULL DEFAULT '0',
  `numhits` int(11) NOT NULL DEFAULT '0',
  `rune` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`pet`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_info` (
  `char_id` int(11) NOT NULL,
  `pet` int(11) NOT NULL,
  `petname` varchar(64) NOT NULL DEFAULT '',
  `petpower` int(11) NOT NULL DEFAULT '0',
  `spell_id` int(11) NOT NULL DEFAULT '0',
  `hp` int(11) NOT NULL DEFAULT '0',
  `mana` int(11) NOT NULL DEFAULT '0',
  `size` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`pet`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_inventory` (
  `char_id` int(11) NOT NULL,
  `pet` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`char_id`,`pet`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_tasks` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  `slot` int(11) unsigned NOT NULL DEFAULT '0',
  `acceptedtime` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`charid`,`taskid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chatchannels` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `owner` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `minstatus` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `completed_tasks` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `completedtime` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  `activityid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`completedtime`,`taskid`,`activityid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discovered_items` (
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `char_name` varchar(64) NOT NULL DEFAULT '',
  `discovered_date` int(11) unsigned NOT NULL DEFAULT '0',
  `account_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accountname` varchar(30) NOT NULL DEFAULT '',
  `accountid` int(10) unsigned DEFAULT '0',
  `status` int(5) NOT NULL DEFAULT '0',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `target` varchar(64) DEFAULT 'None',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `descriptiontype` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `event_nid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5450 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faction_values` (
  `char_id` int(4) NOT NULL DEFAULT '0',
  `faction_id` int(4) NOT NULL DEFAULT '0',
  `current_value` smallint(6) NOT NULL DEFAULT '0',
  `temp` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`faction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends` (
  `charid` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 = Friend, 0 = Ignore',
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`charid`,`type`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_ips` (
  `name` varchar(64) NOT NULL,
  `account_id` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  UNIQUE KEY `account_id` (`account_id`,`ip_address`),
  UNIQUE KEY `account_id_2` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_id` (
  `groupid` int(4) NOT NULL,
  `charid` int(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ismerc` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`,`charid`,`ismerc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_leaders` (
  `gid` int(4) NOT NULL DEFAULT '0',
  `leadername` varchar(64) NOT NULL DEFAULT '',
  `marknpc` varchar(64) NOT NULL DEFAULT '',
  `leadershipaa` tinyblob,
  `maintank` varchar(64) NOT NULL DEFAULT '',
  `assist` varchar(64) NOT NULL DEFAULT '',
  `puller` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guilds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `leader` int(11) NOT NULL DEFAULT '0',
  `minstatus` smallint(5) NOT NULL DEFAULT '0',
  `motd` text NOT NULL,
  `tribute` int(10) unsigned NOT NULL DEFAULT '0',
  `motd_setter` varchar(64) NOT NULL DEFAULT '',
  `channel` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(512) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `leader` (`leader`)
) ENGINE=MyISAM AUTO_INCREMENT=407 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` int(4) unsigned NOT NULL DEFAULT '0',
  `itemid` int(10) unsigned NOT NULL DEFAULT '0',
  `qty` int(10) unsigned NOT NULL DEFAULT '0',
  `donator` varchar(64) DEFAULT NULL,
  `permissions` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `whofor` varchar(64) DEFAULT NULL,
  KEY `guildid` (`guildid`),
  KEY `area` (`area`),
  KEY `slot` (`slot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_ranks` (
  `guild_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '',
  `can_hear` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_speak` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_invite` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_remove` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_promote` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_demote` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_motd` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_warpeace` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild_id`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_relations` (
  `guild1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guild2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `relation` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild1`,`guild2`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_members` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `guild_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tribute_enable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `total_tribute` int(10) unsigned NOT NULL DEFAULT '0',
  `last_tribute` int(10) unsigned NOT NULL DEFAULT '0',
  `banker` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `public_note` text NOT NULL,
  `alt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hackers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `account` text NOT NULL,
  `name` text NOT NULL,
  `hacked` text NOT NULL,
  `zone` text,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1530680 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_list_player` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `slotid` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `itemid` int(11) unsigned DEFAULT '0',
  `charges` smallint(3) unsigned DEFAULT '0',
  `color` int(11) unsigned NOT NULL DEFAULT '0',
  `augslot1` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot2` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot3` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot4` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot5` mediumint(7) unsigned DEFAULT '0',
  `instnodrop` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `custom_data` text,
  PRIMARY KEY (`charid`,`slotid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_tick` (
  `it_itemid` int(11) NOT NULL,
  `it_chance` int(11) NOT NULL,
  `it_level` int(11) NOT NULL,
  `it_id` int(11) NOT NULL AUTO_INCREMENT,
  `it_qglobal` varchar(50) NOT NULL,
  `it_bagslot` tinyint(4) NOT NULL,
  PRIMARY KEY (`it_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyring` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `launcher_zones` (
  `launcher` varchar(64) NOT NULL DEFAULT '',
  `zone` varchar(32) NOT NULL DEFAULT '',
  `port` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`launcher`,`zone`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lfguild` (
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL,
  `comment` varchar(256) NOT NULL,
  `fromlevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tolevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `classes` int(10) unsigned NOT NULL DEFAULT '0',
  `aacount` int(10) unsigned NOT NULL DEFAULT '0',
  `timezone` int(10) unsigned NOT NULL DEFAULT '0',
  `timeposted` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `charid` int(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `from` varchar(100) NOT NULL DEFAULT '',
  `subject` varchar(200) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `to` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgid`),
  KEY `charid` (`charid`)
) ENGINE=MyISAM AUTO_INCREMENT=2477 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchantlist_temp` (
  `npcid` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `itemid` int(10) unsigned NOT NULL DEFAULT '0',
  `charges` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`npcid`,`slot`),
  KEY `npcid_2` (`npcid`,`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `name_filter` (
  `name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_contents` (
  `zoneid` int(11) unsigned NOT NULL DEFAULT '0',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `bagidx` int(11) unsigned NOT NULL DEFAULT '0',
  `itemid` int(11) unsigned NOT NULL DEFAULT '0',
  `charges` smallint(3) NOT NULL DEFAULT '0',
  `droptime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `augslot1` mediumint(7) unsigned DEFAULT '0',
  `augslot2` mediumint(7) unsigned DEFAULT '0',
  `augslot3` mediumint(7) unsigned DEFAULT '0',
  `augslot4` mediumint(7) unsigned DEFAULT '0',
  `augslot5` mediumint(7) unsigned DEFAULT '0',
  PRIMARY KEY (`parentid`,`bagidx`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petitions` (
  `dib` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `petid` int(10) unsigned NOT NULL DEFAULT '0',
  `charname` varchar(32) NOT NULL DEFAULT '',
  `accountname` varchar(32) NOT NULL DEFAULT '',
  `lastgm` varchar(32) NOT NULL DEFAULT '',
  `petitiontext` text NOT NULL,
  `gmtext` text,
  `zone` varchar(32) NOT NULL DEFAULT '',
  `urgency` int(11) NOT NULL DEFAULT '0',
  `charclass` int(11) NOT NULL DEFAULT '0',
  `charrace` int(11) NOT NULL DEFAULT '0',
  `charlevel` int(11) NOT NULL DEFAULT '0',
  `checkouts` int(11) NOT NULL DEFAULT '0',
  `unavailables` int(11) NOT NULL DEFAULT '0',
  `ischeckedout` tinyint(4) NOT NULL DEFAULT '0',
  `senttime` bigint(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dib`),
  KEY `petid` (`petid`)
) ENGINE=MyISAM AUTO_INCREMENT=2139 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_corpses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `zoneid` smallint(5) NOT NULL DEFAULT '0',
  `instanceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `heading` float NOT NULL DEFAULT '0',
  `data` blob,
  `timeofdeath` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rezzed` tinyint(3) unsigned DEFAULT '0',
  `IsBurried` tinyint(3) NOT NULL DEFAULT '0',
  `WasAtGraveyard` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `zoneid` (`zoneid`),
  KEY `instanceid` (`instanceid`)
) ENGINE=InnoDB AUTO_INCREMENT=1126174 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_corpses_backup` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `zoneid` smallint(5) NOT NULL DEFAULT '0',
  `instanceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `heading` float NOT NULL DEFAULT '0',
  `data` blob,
  `timeofdeath` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rezzed` tinyint(3) unsigned DEFAULT '0',
  `IsBurried` tinyint(3) NOT NULL DEFAULT '0',
  `WasAtGraveyard` tinyint(3) NOT NULL DEFAULT '0',
  `parent_corpse_id` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_titlesets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(11) unsigned NOT NULL,
  `title_set` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=717 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_move_record` (
  `move_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `char_id` int(11) DEFAULT '0',
  `from_slot` mediumint(7) DEFAULT '0',
  `to_slot` mediumint(7) DEFAULT '0',
  `stack_size` mediumint(7) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  `postaction` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`move_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_move_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `from_slot` mediumint(7) DEFAULT '0',
  `to_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_npc_kill_record` (
  `fight_id` int(11) NOT NULL AUTO_INCREMENT,
  `npc_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fight_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_npc_kill_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `char_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_speech` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(64) NOT NULL,
  `to` varchar(64) NOT NULL,
  `message` varchar(256) NOT NULL,
  `minstatus` smallint(5) NOT NULL,
  `guilddbid` int(11) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `timerecorded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_trade_record` (
  `trade_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `char1_id` int(11) DEFAULT '0',
  `char1_pp` int(11) DEFAULT '0',
  `char1_gp` int(11) DEFAULT '0',
  `char1_sp` int(11) DEFAULT '0',
  `char1_cp` int(11) DEFAULT '0',
  `char1_items` mediumint(7) DEFAULT '0',
  `char2_id` int(11) DEFAULT '0',
  `char2_pp` int(11) DEFAULT '0',
  `char2_gp` int(11) DEFAULT '0',
  `char2_sp` int(11) DEFAULT '0',
  `char2_cp` int(11) DEFAULT '0',
  `char2_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`trade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_trade_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `from_id` int(11) DEFAULT '0',
  `from_slot` mediumint(7) DEFAULT '0',
  `to_id` int(11) DEFAULT '0',
  `to_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_merchant_transaction_record` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `zone_id` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `merchant_pp` int(11) DEFAULT '0',
  `merchant_gp` int(11) DEFAULT '0',
  `merchant_sp` int(11) DEFAULT '0',
  `merchant_cp` int(11) DEFAULT '0',
  `merchant_items` mediumint(7) DEFAULT '0',
  `char_id` int(11) DEFAULT '0',
  `char_pp` int(11) DEFAULT '0',
  `char_gp` int(11) DEFAULT '0',
  `char_sp` int(11) DEFAULT '0',
  `char_cp` int(11) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_merchant_transaction_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `char_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_delete_record` (
  `delete_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `char_id` int(11) DEFAULT '0',
  `stack_size` mediumint(7) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`delete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_delete_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `char_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_handin_record` (
  `handin_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `quest_id` int(11) DEFAULT '0',
  `char_id` int(11) DEFAULT '0',
  `char_pp` int(11) DEFAULT '0',
  `char_gp` int(11) DEFAULT '0',
  `char_sp` int(11) DEFAULT '0',
  `char_cp` int(11) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  `npc_id` int(11) DEFAULT '0',
  `npc_pp` int(11) DEFAULT '0',
  `npc_gp` int(11) DEFAULT '0',
  `npc_sp` int(11) DEFAULT '0',
  `npc_cp` int(11) DEFAULT '0',
  `npc_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`handin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_handin_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `action_type` char(6) DEFAULT 'action',
  `char_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_globals` (
  `charid` int(11) NOT NULL DEFAULT '0',
  `npcid` int(11) NOT NULL DEFAULT '0',
  `zoneid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(65) NOT NULL DEFAULT '',
  `value` varchar(128) NOT NULL DEFAULT '?',
  `expdate` int(11) DEFAULT NULL,
  PRIMARY KEY (`charid`,`npcid`,`zoneid`,`name`),
  UNIQUE KEY `qname` (`name`,`charid`,`npcid`,`zoneid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raid_details` (
  `raidid` int(4) NOT NULL DEFAULT '0',
  `loottype` int(4) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`raidid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raid_members` (
  `raidid` int(4) NOT NULL DEFAULT '0',
  `charid` int(4) NOT NULL DEFAULT '0',
  `groupid` int(4) NOT NULL DEFAULT '0',
  `_class` tinyint(4) NOT NULL DEFAULT '0',
  `level` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `isgroupleader` tinyint(1) NOT NULL DEFAULT '0',
  `israidleader` tinyint(1) NOT NULL DEFAULT '0',
  `islooter` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `reported` varchar(64) DEFAULT NULL,
  `reported_text` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respawn_times` (
  `id` int(11) NOT NULL DEFAULT '0',
  `start` int(11) NOT NULL DEFAULT '0',
  `duration` int(11) NOT NULL DEFAULT '0',
  `instance_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sharedbank` (
  `acctid` int(11) unsigned DEFAULT '0',
  `slotid` mediumint(7) unsigned DEFAULT '0',
  `itemid` int(11) unsigned DEFAULT '0',
  `charges` smallint(3) unsigned DEFAULT '0',
  `augslot1` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot2` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot3` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot4` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot5` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `custom_data` text,
  UNIQUE KEY `account` (`acctid`,`slotid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spell_globals` (
  `spellid` int(11) NOT NULL,
  `spell_name` varchar(64) NOT NULL DEFAULT '',
  `qglobal` varchar(65) NOT NULL DEFAULT '',
  `value` varchar(65) NOT NULL DEFAULT '',
  PRIMARY KEY (`spellid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timers` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `type` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `start` int(10) unsigned NOT NULL DEFAULT '0',
  `duration` int(10) unsigned NOT NULL DEFAULT '0',
  `enable` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trader` (
  `char_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `serialnumber` int(10) unsigned NOT NULL DEFAULT '0',
  `charges` int(11) NOT NULL DEFAULT '0',
  `item_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `slot_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`slot_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trader_audit` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `seller` varchar(64) NOT NULL DEFAULT '',
  `buyer` varchar(64) NOT NULL DEFAULT '',
  `itemname` varchar(64) NOT NULL DEFAULT '',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `totalcost` int(11) NOT NULL DEFAULT '0',
  `trantype` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zone_flags` (
  `charID` int(11) NOT NULL DEFAULT '0',
  `zoneID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charID`,`zoneID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands` (
  `command` varchar(128) NOT NULL DEFAULT '',
  `access` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`command`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `commands` VALUES ('appearance',150),('attack',150),('bind',80),('ban',200),('cast',90),('castspell',90),('chat',200),('copychar',200),('crashtest',201),('damage',150),('date',150),('dbspawn2',100),('delacct',200),('deletecorpse',100),('deletenpccorpses',100),('deleteplayercorpses',100),('depop',100),('depopcorpses',100),('depopzone',100),('emote',150),('finditem',90),('findnpctype',90),('findspell',90),('fixmob',150),('flag',201),('flymode',80),('freeze',100),('gassign',150),('gender',90),('giveitem',150),('gm',80),('gmspeed',80),('goto',80),('grid',150),('guild',80),('haste',100),('heal',100),('hideme',80),('invul',80),('invulnerable',80),('itemsearch',90),('kick',80),('kill',80),('lastname',80),('level',150),('listnpccorpses',90),('listnpcs',90),('listpetition',80),('listplayercorpses',90),('loc',0),('lock',200),('makepet',150),('mana',100),('memspell',100),('motd',200),('movechar',80),('name',100),('npccast',90),('npcedit',150),('qglobal',150),('npcloot',150),('npcshout',90),('npcspawn',100),('npcspecialattk',150),('npcstats',90),('npctypespawn',90),('nukebuffs',100),('peqzone',2),('permaclass',150),('permagender',150),('permarace',150),('pvp',80),('race',90),('refundaa',100),('repop',90),('reloadqst',80),('save',80),('scribespells',100),('search',90),('sendzonespawns',200),('serverinfo',201),('resetaa',100),('setaapts',100),('setaaxp',100),('setallskill',100),('setitemstatus',200),('setskill',90),('setskillall',100),('setxp',100),('showbuffs',80),('showpetspell',80),('showstats',80),('shutdown',200),('size',90),('spawn',150),('spawnfix',80),('spawnstatus',150),('spon',0),('spoff',0),('spfind',150),('summon',80),('summonitem',150),('texture',150),('timeofday',90),('title',100),('traindisc',100),('unfreeze',100),('unlock',150),('unscribespells',100),('viewpetition',80),('weather',90),('worldshutdown',200),('wp',150),('zclip',150),('zcolor',150),('zcolour',150),('zheader',150),('zone',80),('zonebootup',100),('zonelock',200),('zoneshutdown',200),('zsafecoords',150),('zsave',200),('zsky',150),('wpinfo',150),('charbackup',80),('revoke',80),('flagedit',150),('flags',80),('corpse',90),('delpetition',80),('peekinv',80),('scribespell',90),('unscribespell',90),('setadventurepoints',200),('wpadd',150),('datarate',0),('ipban',201),('aggrozone',200),('melody',0),('undyeme',0),('findzone',1),('fz',1),('altactivate',90),('hp',90),('bestz',80),('serverrules',90),('acceptrules',90),('serversidename',90),('zoneinstance',80),('givemoney',150),('npcsay',80),('randomfeatures',90),('tgzone',1),('setstartzone',80),('netstats',200),('rules',200),('suspend',100),('tgczone',3),('setlsinfo',0),('cvs',80),('instance',80),('mysql',255),('npcemote',80),('reloadworld',255),('reloadlevelmods',255),('maxskills',90),('questerrors',0);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `launcher` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `dynamics` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `launcher` VALUES ('peq',40),('zone',5);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_sets` (
  `ruleset_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ruleset_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `rule_sets` VALUES (3,'merc_test'),(1,'default'),(2,'pop+'),(10,'EQEmu_Default'),(4,'GoD');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_values` (
  `ruleset_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rule_name` varchar(64) NOT NULL DEFAULT '',
  `rule_value` varchar(10) NOT NULL DEFAULT '',
  `notes` text NOT NULL,
  PRIMARY KEY (`ruleset_id`,`rule_name`),
  KEY `ruleset_id` (`ruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `rule_values` VALUES (2,'GM:MinStatusToZoneAnywhere','250','This setting overrides the minstatus setting in the zones table if set'),(2,'Character:MaxLevel','65','notation'),(2,'Character:LeaveCorpses','true','notation'),(2,'Character:LeaveNakedCorpses','true','notation'),(2,'Character:DeathExpLossLevel','10','notation'),(2,'Character:CorpseDecayTimeMS','43200000','notation'),(2,'Character:AutosaveIntervalS','300','0=disabled'),(2,'Character:HPRegenMultiplier','100','notation'),(2,'Character:ManaRegenMultiplier','100','notation'),(2,'Character:EnduranceRegenMultiplier','100','notation'),(2,'Guild:MaxMembers','2048','Max number of members allowed in a single guild'),(2,'Skills:MaxTrainTradeskills','21','Highest skill level that tradeskills can be trained to from GM Trainers'),(2,'Pets:AttackCommandRange','200','Range at which a pet will respond to attack commands'),(2,'World:ZoneAutobootTimeoutMS','120000','notation'),(2,'World:ClientKeepaliveTimeoutMS','95000','notation'),(2,'Combat:FleeHPRatio','21',''),(2,'World:ExemptMaxClientsStatus','-1','Exempt accounts from the MaxClientsPerIP and AddMaxClientsStatus rules:if their status is >= this value.  Default value: -1 (feature disabled)'),(2,'Combat:EnableFearPathing','true',''),(2,'Combat:MeleeBaseCritChance','0','The base crit chance for non warriors:NOTE: This will apply to NPCs as well'),(2,'Combat:WarBerBaseCritChance','3','The base crit chance for warriors and berserkers:only applies to clients'),(2,'Combat:BerserkBaseCritChance','6',''),(2,'Combat:NPCBashKickLevel','6',''),(2,'Character:ConsumptionMultiplier','100',''),(2,'Spells:AutoResistDiff','15','notation'),(2,'Spells:ResistChance','2.0','chance to resist given no resists and same level'),(2,'Spells:ResistMod','0.40','multiplier:chance to resist = this * ResistAmount'),(2,'Spells:PartialHitChance','0.7','The chance when a spell is resisted that it will partial hit.'),(2,'Combat:ClientBaseCritChance','0',''),(2,'Zone:NPCPositonUpdateTicCount','32','ms between intervals of sending a position update to the entire zone.'),(2,'NPC:MinorNPCCorpseDecayTimeMS','600000','level<55'),(2,'NPC:MajorNPCCorpseDecayTimeMS','1800000','level>=55'),(2,'NPC:UseItemBonusesForNonPets','true','notation'),(2,'Character:ExpMultiplier','0.65','notation'),(2,'Zone:EnableShadowrest','1',''),(2,'Zone:GraveyardTimeMS','1200000',''),(2,'Map:FixPathingZWhenLoading','true',''),(2,'Map:FixPathingZAtWaypoints','true',''),(2,'Map:FixPathingZWhenMoving','true',''),(2,'Map:FixPathingZOnSendTo','false',''),(2,'Zone:ClientLinkdeadMS','180000',''),(2,'Map:FixPathingZMaxDeltaSendTo','20',''),(2,'Map:FixPathingZMaxDeltaLoading','20',''),(2,'Map:FixPathingZMaxDeltaMoving','20',''),(2,'Map:FixPathingZMaxDeltaWaypoint','20',''),(2,'Character:HealOnLevel','false','notation'),(2,'Character:FeignKillsPet','false','notation'),(2,'Character:ItemManaRegenCap','15','notation'),(2,'Character:ItemHealthRegenCap','15','notation'),(2,'Combat:UseIntervalAC','true',''),(2,'Combat:PetAttackMagicLevel','30',''),(2,'NPC:SayPauseTimeInSec','10','notation'),(2,'NPC:OOCRegen','1','notation'),(2,'Watermap:CheckWaypointsInWaterWhenLoading','true',''),(2,'Watermap:CheckForWaterAtWaypoints','true',''),(2,'Watermap:CheckForWaterWhenMoving','true',''),(2,'Watermap:CheckForWaterOnSendTo','false','Checks if a mob has moved into/out of water on SendTo'),(2,'Watermap:CheckForWaterWhenFishing','true','Only lets a player fish near water (if a water map exists for the zone)'),(2,'Watermap:FishingRodLength','30','How far in front of player water must be for fishing to work'),(2,'Watermap:FishingLineLength','40','If water is more than this far below the player:it is considered too far to fish'),(2,'Aggro:SmartAggroList','true','notation'),(2,'Aggro:SittingAggroMod','35','notation'),(2,'Aggro:MeleeRangeAggroMod','20','notation'),(2,'Aggro:CurrentTargetAggroMod','0','0 will prefer our current target to any other, > 0 makes it harder for our npcs to switch targets.'),(2,'Aggro:CriticallyWoundedAggroMod','100','notation'),(2,'Combat:AssistNoTargetSelf','false','When assisting a target without a target: true = target self, false = leave target as was before assist (this is the behavior on live)'),(2,'NPC:BuffFriends','false','notation'),(2,'Aggro:SpellAggroMod','100','notation'),(2,'Aggro:SongAggroMod','33','notation'),(2,'Aggro:PetSpellAggroMod','10','notation'),(2,'Character:DeathItemLossLevel','10','notation'),(2,'Zone:EnableMQGhostDetector','true',''),(2,'Zone:EnableMQGateDetector','true',''),(2,'World:MaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < AddMaxClientsStatus.  Default value: -1 (feature disabled)'),(2,'Zone:EnableMQZoneDetector','true',''),(2,'Zone:EnableMQWarpDetector','true',''),(2,'Combat:FleeIfNotAlone','false',''),(2,'Zone:MQGhostExemptStatus','80',''),(2,'Zone:MQGateExemptStatus','80',''),(2,'Zone:MQZoneExemptStatus','80',''),(2,'Character:ItemDamageShieldCap','30','notation'),(2,'Character:ItemAccuracyCap','150','notation'),(2,'Character:ItemAvoidanceCap','100','notation'),(2,'Character:ItemCombatEffectsCap','100','notation'),(2,'Character:ItemShieldingCap','35','notation'),(2,'Character:ItemSpellShieldingCap','35','notation'),(2,'Character:ItemDoTShieldingCap','35','notation'),(2,'Character:ItemStunResistCap','35','notation'),(2,'Character:ItemStrikethroughCap','35','notation'),(2,'Zone:MQWarpDetectionDistanceFactor','9.0',''),(2,'Zone:MQWarpExemptStatus','80',''),(2,'World:UseBannedIPsTable','true','Toggle whether or not to check incoming client connections against the Banned_IPs table. Set this value to false to disable this feature.'),(2,'Spells:PartialHitChanceFear','0.25','The chance when a fear spell is resisted that it will partial hit.'),(2,'NPC:EmptyNPCCorpseDecayTimeMS','0','notation'),(2,'NPC:CorpseUnlockTimer','150000','notation'),(2,'NPC:EnableNPCQuestJournal','true','notation'),(2,'Character:SkillUpModifier','100','skill ups are at 100%'),(2,'TaskSystem:EnableTaskSystem','true','Globally enable or disable the Task system'),(2,'TaskSystem:PeriodicCheckTimer','5',''),(2,'TaskSystem:RecordCompletedTasks','true','notation'),(2,'TaskSystem:RecordCompletedOptionalActivities','true','notation'),(2,'TaskSystem:KeepOneRecordPerCompletedTask','true','notation'),(2,'TaskSystem:EnableTaskProximity','true','notation'),(2,'World:EnableTutorialButton','true','notation'),(2,'World:EnableReturnHomeButton','true','notation'),(2,'World:MaxLevelForTutorial','15','notation'),(2,'World:MinOfflineTimeToReturnHome','21600','21600 seconds is 6 Hours'),(2,'World:AddMaxClientsStatus','-1','Accounts with status >= this rule will be allowed to use the amount of accounts defined in the AddMaxClientsPerIP.  Default value: -1 (feature disabled)'),(2,'World:AddMaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < ExemptMaxClientsStatus.  Default value: -1 (feature disabled)'),(2,'World:ClearTempMerchantlist','false','cavedude: Clears temp merchant items when world boots.'),(2,'Character:MaxExpLevel','65','Sets the Max Level attainable via Experience'),(2,'Zone:AutoShutdownDelay','5000',''),(2,'Chat:ServerWideOOC','true','notation'),(2,'Chat:ServerWideAuction','true','notation'),(2,'Combat:AdjustProcPerMinute','true','notation'),(2,'Combat:AvgProcsPerMinute','2.0','notation'),(2,'Combat:ProcPerMinDexContrib','0.075','notation'),(2,'Combat:BaseProcChance','0.035','notation'),(2,'Combat:ProcDexDivideBy','11000','notation'),(2,'Spells:BaseCritChance','0','base % chance that everyone has to crit a spell'),(2,'Spells:BaseCritRatio','100','base % bonus to damage on a successful spell crit. 100 = 2x damage'),(2,'Spells:WizCritLevel','12','level wizards first get spell crits'),(2,'Spells:WizCritChance','5',''),(2,'Spells:WizCritRatio','0',''),(2,'Character:SharedBankPlat','true','off by default to prevent duping for now'),(2,'Spells:ResistPerLevelDiff','85','8.5 resist per level difference.'),(2,'Combat:BaseHitChance','69','notation'),(2,'Combat:AgiHitFactor','0.01','notation'),(2,'Character:DeathExpLossMultiplier','3','Adjust how much exp is lost'),(2,'Character:UseDeathExpLossMult','false','Adjust to use the above multiplier or to use code default.'),(2,'Character:BindAnywhere','false','notation'),(2,'World:AccountSessionLimit','1','Max number of characters allowed on at once from a single account (-1 is disabled)'),(2,'World:ExemptAccountLimitStatus','200','Min status required to be exempt from multi-session per account limiting (-1 is disabled)'),(2,'Bazaar:AuditTrail','true','notation'),(2,'Bazaar:MaxSearchResults','200','notation'),(2,'World:TutorialZoneID','189','notation'),(2,'Bazaar:EnableWarpToTrader','true','notation'),(2,'Bazaar:MaxBarterSearchResults','200','The max results returned in the /barter search'),(2,'Mail:EnableMailSystem','true','If false:client wont bring up the Mail window.'),(2,'Mail:ExpireTrash','0','Time in seconds. 0 will delete all messages in the trash when the mailserver starts'),(2,'Mail:ExpireRead','31536000','1 Year. Set to -1 for never'),(2,'Mail:ExpireUnread','31536000','1 Year. Set to -1 for never'),(2,'Channels:RequiredStatusAdmin','251','Required status to administer chat channels'),(2,'Channels:RequiredStatusListAll','251','Required status to list all chat channels'),(2,'Channels:DeleteTimer','1440','Empty password protected channels will be deleted after this many minutes'),(2,'Chat:EnableVoiceMacros','true','notation'),(2,'Spells:TranslocateTimeLimit','0','If not zero:time in seconds to accept a Translocate.'),(2,'EventLog:RecordSellToMerchant','false','Record sales from a player to an NPC merchant in eventlog table'),(2,'EventLog:RecordBuyFromMerchant','false','Record purchases by a player from an NPC merchant in eventlog table'),(2,'Character:AAExpMultiplier','0.65','notation'),(2,'World:GMAccountIPList','true','Check ip list against GM Accounts:AntiHack GM Accounts.'),(2,'Merchant:UsePriceMod','true','Use faction/charisma price modifiers.'),(2,'Merchant:SellCostMod','1.05','Modifier for NPC sell price.'),(2,'Merchant:BuyCostMod','0.95','Modifier for NPC buy price.'),(2,'Merchant:PriceBonusPct','4','Determines maximum price bonus from having good faction/CHA. Value is a percent.'),(2,'Merchant:PricePenaltyPct','4','Determines maximum price penalty from having bad faction/CHA. Value is a percent.'),(2,'Merchant:ChaBonusMod','3.45','Determines CHA cap:from 104 CHA. 3.45 is 132 CHA at apprehensive. 0.34 is 400 CHA at apprehensive.'),(2,'Merchant:ChaPenaltyMod','1.52','Determines CHA bottom:up to 102 CHA. 1.52 is 37 CHA at apprehensive. 0.98 is 0 CHA at apprehensive.'),(2,'Combat:HitFalloffMinor','5.0','hit will fall off up to 5% over the initial level range'),(2,'Combat:HitFalloffModerate','7.0','hit will fall off up to 7% over the three levels after the initial level range'),(2,'Combat:HitFalloffMajor','50.0',''),(2,'Combat:HitBonusPerLevel','1.2',''),(2,'Combat:WeaponSkillFalloff','0.33',''),(2,'Combat:ArcheryHitPenalty','0.45','Archery has a hit penalty to try to help balance it with the plethora of long term +hit modifiers for it'),(2,'Chat:EnableMailKeyIPVerification','true','notation'),(2,'Chat:EnableAntiSpam','true','notation'),(2,'Chat:MinStatusToBypassAntiSpam','80','notation'),(2,'Chat:MinimumMessagesPerInterval','4','notation'),(2,'Chat:MaximumMessagesPerInterval','12','notation'),(2,'Chat:MaxMessagesBeforeKick','20','notation'),(2,'Chat:IntervalDurationMS','60000','notation'),(2,'Chat:KarmaUpdateIntervalMS','1200000','notation'),(2,'Character:GroupExpMultiplier','0.65','notation'),(2,'Character:RaidExpMultiplier','0.2','notation'),(2,'World:MinGMAntiHackStatus','11','Minimum GM status to check against AntiHack list'),(2,'Character:RestRegenPercent','0','Set to >0 to enable rest state bonus HP and mana regen.'),(2,'Character:RestRegenTimeToActivate','30000','Time in seconds for rest state regen to kick in.'),(2,'Zone:UsePEQZoneDebuffs','false','Will determine if #peqzone will debuff players or not when used.'),(2,'Combat:NPCBonusHitChance','26.0','notation'),(2,'Character:UseXPConScaling','true',''),(2,'Character:LightBlueModifier','40',''),(2,'Character:BlueModifier','90',''),(2,'Character:WhiteModifier','100',''),(2,'Character:YellowModifier','125',''),(2,'Character:RedModifier','150',''),(2,'Character:KillsPerRaidLeadershipAA','250',''),(2,'Character:KillsPerGroupLeadershipAA','250',''),(2,'Adventure:ItemIDToEnablePorts','41000',''),(2,'Adventure:MinNumberForGroup','2',''),(2,'Adventure:MaxNumberForGroup','6',''),(2,'Adventure:MinNumberForRaid','18',''),(2,'Adventure:MaxNumberForRaid','36',''),(2,'Adventure:MaxLevelRange','9',''),(2,'Adventure:NumberKillsForBossSpawn','40',''),(2,'Adventure:DistanceForRescueAccept','10000.0',''),(2,'Adventure:DistanceForRescueComplete','2500.0',''),(2,'Pathing:Aggro','true',''),(2,'Pathing:AggroReturnToGrid','true',''),(2,'Pathing:CandidateNodeRangeXY','400.000000',''),(2,'Zone:PEQZoneReuseTime','300','Amount of time, in seconds, before you can reuse the #peqzone command'),(2,'Zone:PEQZoneDebuff1','4454','First debuff casted by #peqzone Default is Cursed Keepers Blight.'),(2,'Zone:PEQZoneDebuff2','2209','Second debuff casted by #peqzone Default is Tendrils of Apathy.'),(2,'NPC:LastFightingDelayMovingMin','5000','Minimum time (in ms) before mob goes home after all aggro loss'),(2,'NPC:LastFightingDelayMovingMax','20000','Maximum time (in ms) before mob goes home after all aggro loss'),(2,'Combat:ArcheryBonusRequiresStationary','true','does the 2x archery bonus chance require a stationary npc'),(2,'NPC:SmartLastFightingDelayMoving','true','When true, mobs that started going home previously will do so again immediately if still on FD hate list'),(2,'Pathing:CandidateNodeRangeZ','50.0000000',''),(2,'Pathing:CullNodesFromEnd','1',''),(2,'Pathing:CullNodesFromStart','1',''),(2,'Pathing:Fear','true',''),(2,'Combat:ArcheryBaseDamageBonus','1','Modifier to Base Archery Damage .5 = 50%, 1 = 100%, 2 = 200%'),(2,'Pathing:Guard','true',''),(2,'Pathing:LOSCheckFrequency','1000',''),(2,'Pathing:MaxNodesLeftForLOSCheck','4',''),(2,'Pathing:MinDistanceForLOSCheckLong','1000000.00',''),(2,'Pathing:MinDistanceForLOSCheckShort','40000.0000',''),(2,'Pathing:MinNodesTraversedForLOSCheck','3',''),(2,'Pathing:RouteUpdateFrequencyLong','5000',''),(2,'Pathing:RouteUpdateFrequencyNodeCount','5',''),(2,'Pathing:RouteUpdateFrequencyShort','1000',''),(2,'Pathing:ZDiffThreshold','10.0000000',''),(2,'Map:FindBestZHeightAdjust','1',''),(2,'Map:UseClosestZ','true',''),(2,'Spells:SacrificeMinLevel','46','First level Sacrifice will work on'),(2,'Spells:SacrificeMaxLevel','69','Last level Sacrifice will work on'),(2,'Spells:SacrificeItemID','9963','Item ID of the item Sacrifice will return. Defaults to an Essence Emerald.'),(2,'Combat:MaxRampageTargets','3','max number of people hit with rampage'),(2,'Combat:MaxFlurryHits','2','max number of extra hits from flurry'),(2,'Combat:MonkDamageTableBonus','10','% bonus monks get to their damage table calcs'),(2,'Combat:FlyingKickBonus','25','% Modifier that this skill gets to str and skill bonuses'),(2,'Combat:DragonPunchBonus','20','% Modifier that this skill gets to str and skill bonuses'),(2,'Combat:EagleStrikeBonus','15','% Modifier that this skill gets to str and skill bonuses'),(2,'Combat:TigerClawBonus','10','% Modifier that this skill gets to str and skill bonuses'),(2,'Combat:RoundKickBonus','5','% Modifier that this skill gets to str and skill bonuses'),(2,'AA:MaxEffectSlots','7','the highest slot # used in the aa_effects table. have to use MAX_AA_EFFECT_SLOTS for now'),(2,'Character:MaxFearDurationForPlayerCharacter','4','4 tics, each tic calculates every 6 seconds.'),(2,'Character:MaxCharmDurationForPlayerCharacter','15','15 tics, each tic calculates every 6 seconds.'),(2,'AA:ExpPerPoint','23976503','Amount of exp per AA. Is the same as the amount of exp to go from level 51 to level 52.'),(2,'World:MaxClientsSetByStatus','false','If True, IP Limiting will be set to the status on the account as long as the status is > MaxClientsPerIP'),(2,'Combat:FleeSnareHPRatio','21','HP at which snare will halt movement of a fleeing NPC.'),(2,'Chat:KarmaGlobalChatLimit','72','amount of karma you need to be able to talk in ooc/auction/chat below the level limit'),(2,'Chat:GlobalChatLevelLimit','5','level limit you need to of reached to talk in ooc/auction/chat if your karma is too low.'),(2,'Zone:HotZoneBonus','0.75','hot zone XP bonus'),(2,'Zone:MarkMQWarpLT','false',''),(2,'Spells:EnableSpellGlobals','false','If true, spells check the spell_globals table against quest globals before allowing spells to scribe via quest::scribespell'),(2,'NPC:ReturnNonQuestNoDropItems','true','Return NO DROP items on NPCs that do not have an EVENT_ITEM sub in their script'),(2,'World:GuildBankZoneID','345','ID of zone the Guild Bank works in. Default 345, guildhall'),(2,'Character:DeathExpLossMaxLevel','255','Any level greater than this will no longer lose exp on death'),(2,'Skills:UseLimitTradeskillSearchSkillDiff','true','Enables the limit for the maximum difference between trivial and skill for recipe searches and favorites.'),(2,'Skills:MaxTradeskillSearchSkillDiff','50','The maximum difference in skill between the trivial of an item and the skill of the player if the trivial is higher than the skill. Recipes that have not been learnt or made at least once via the Experiment mode will be removed from searches based on this criteria.'),(2,'Character:SoDClientUseSoDHPManaEnd','true','Setting this to true will allow SoD clients to use the SoD HP/Mana/End formulas and previous clients will use the old formulas'),(2,'Spells:MaxBuffSlotsNPC','25',''),(2,'Spells:MaxSongSlotsNPC','10',''),(2,'Spells:MaxDiscSlotsNPC','1',''),(2,'Spells:MaxTotalSlotsNPC','36',''),(2,'Chracter:DeathExpLossMaxLevel','255','Any level greater than this will no longer lose exp on death'),(1,'Skills:MaxTrainSpecializations','50','Max level a GM trainer will train casting specializations'),(1,'World:IsGMPetitionWindowEnabled','false',''),(1,'Spells:ReflectType','1','0 = disabled, 1 = single target player spells only, 2 = all player spells, 3 = all single target spells, 4 = all spells'),(1,'Character:UseNewStatsWindow','true',''),(1,'Character:ItemDSMitigationCap','50','Mitigates the effect of a damage shield'),(1,'Character:ItemSpellDmgCap','250','Spell Dmg adds to DD spells based on their cast & recast time'),(1,'Character:ItemHealAmtCap','250','Heal Amt adds to heal spells based on their cast & recast time'),(1,'Character:ItemClairvoyanceCap','250','Clairvoyance returns mana after a cast under certain circumstances'),(1,'Spells:EnableBlockedBuffs','true',''),(1,'Combat:NPCBashKickStunChance','15','Percent chance that a bash/kick will stun'),(1,'Character:ItemEnduranceRegenCap','15','Endurance cap from items'),(1,'Character:RespawnFromHoverTimer','300','Respawn Window Timer in Seconds.'),(1,'Character:RespawnFromHover','false','Enable Respawn Window for SoF and later clients.'),(1,'Spells:MaxTotalSlotsNPC','36',''),(1,'Spells:MaxSongSlotsNPC','10',''),(1,'Spells:MaxDiscSlotsNPC','1',''),(1,'Spells:MaxBuffSlotsNPC','25',''),(1,'Character:SoDClientUseSoDHPManaEnd','true','Setting this to true will allow SoD clients to use the SoD HP/Mana/End formulas and previous clients will use the old formulas'),(1,'Skills:MaxTradeskillSearchSkillDiff','50','The maximum difference in skill between the trivial of an item and the skill of the player if the trivial is higher than the skill. Recipes that have not been learnt or made at least once via the Experiment mode will be removed from searches based on this criteria.'),(1,'Skills:UseLimitTradeskillSearchSkillDiff','true','Enables the limit for the maximum difference between trivial and skill for recipe searches and favorites.'),(1,'Character:DeathExpLossMaxLevel','255','Any level greater than this will no longer lose exp on death'),(1,'World:GuildBankZoneID','345','ID of zone the Guild Bank works in. Default 345, guildhall'),(1,'NPC:ReturnNonQuestNoDropItems','true','Return NO DROP items on NPCs that do not have an EVENT_ITEM sub in their script'),(1,'Spells:EnableSpellGlobals','false','If true, spells check the spell_globals table against quest globals before allowing spells to scribe via quest::scribespell'),(1,'Zone:MarkMQWarpLT','false',''),(1,'Zone:HotZoneBonus','0.75','hot zone XP bonus'),(1,'Chat:GlobalChatLevelLimit','5','level limit you need to of reached to talk in ooc/auction/chat if your karma is too low.'),(1,'Chat:KarmaGlobalChatLimit','72','amount of karma you need to be able to talk in ooc/auction/chat below the level limit'),(1,'Combat:FleeSnareHPRatio','21','HP at which snare will halt movement of a fleeing NPC.'),(1,'World:MaxClientsSetByStatus','false','If True, IP Limiting will be set to the status on the account as long as the status is > MaxClientsPerIP'),(1,'AA:ExpPerPoint','23976503','Amount of exp per AA. Is the same as the amount of exp to go from level 51 to level 52.'),(1,'Character:MaxFearDurationForPlayerCharacter','4','4 tics, each tic calculates every 6 seconds.'),(1,'Character:MaxCharmDurationForPlayerCharacter','15','15 tics, each tic calculates every 6 seconds.'),(1,'AA:MaxEffectSlots','7','the highest slot # used in the aa_effects table. have to use MAX_AA_EFFECT_SLOTS for now'),(1,'Combat:RoundKickBonus','5','% Modifier that this skill gets to str and skill bonuses'),(1,'Combat:TigerClawBonus','10','% Modifier that this skill gets to str and skill bonuses'),(1,'Combat:EagleStrikeBonus','15','% Modifier that this skill gets to str and skill bonuses'),(1,'Combat:DragonPunchBonus','20','% Modifier that this skill gets to str and skill bonuses'),(1,'Combat:FlyingKickBonus','25','% Modifier that this skill gets to str and skill bonuses'),(1,'Combat:MonkDamageTableBonus','10','% bonus monks get to their damage table calcs'),(1,'Combat:MaxFlurryHits','2','max number of extra hits from flurry'),(1,'Combat:MaxRampageTargets','3','max number of people hit with rampage'),(1,'Spells:SacrificeItemID','9963','Item ID of the item Sacrifice will return. Defaults to an Essence Emerald.'),(1,'Spells:SacrificeMaxLevel','69','Last level Sacrifice will work on'),(1,'Spells:SacrificeMinLevel','46','First level Sacrifice will work on'),(1,'Map:UseClosestZ','true',''),(1,'Map:FindBestZHeightAdjust','1',''),(1,'Pathing:ZDiffThreshold','10.0000000',''),(1,'Pathing:RouteUpdateFrequencyShort','1000',''),(1,'Pathing:RouteUpdateFrequencyNodeCount','5',''),(1,'Pathing:MinDistanceForLOSCheckShort','40000.0000',''),(1,'Pathing:MinNodesTraversedForLOSCheck','3',''),(1,'Pathing:RouteUpdateFrequencyLong','5000',''),(1,'Pathing:LOSCheckFrequency','1000',''),(1,'Pathing:MaxNodesLeftForLOSCheck','4',''),(1,'Pathing:MinDistanceForLOSCheckLong','1000000.00',''),(1,'Pathing:Guard','true',''),(1,'Combat:ArcheryBaseDamageBonus','1','Modifier to Base Archery Damage .5 = 50%, 1 = 100%, 2 = 200%'),(1,'Pathing:Fear','true',''),(1,'Pathing:CullNodesFromStart','1',''),(1,'Pathing:CullNodesFromEnd','1',''),(1,'Pathing:CandidateNodeRangeZ','50.0000000',''),(1,'NPC:SmartLastFightingDelayMoving','true','When true, mobs that started going home previously will do so again immediately if still on FD hate list'),(1,'Combat:ArcheryBonusRequiresStationary','true','does the 2x archery bonus chance require a stationary npc'),(1,'NPC:LastFightingDelayMovingMax','30000','Maximum time (in ms) before mob goes home after all aggro loss'),(1,'NPC:LastFightingDelayMovingMin','5000','Minimum time (in ms) before mob goes home after all aggro loss'),(1,'Zone:PEQZoneDebuff2','2209','Second debuff casted by #peqzone Default is Tendrils of Apathy.'),(1,'Zone:PEQZoneDebuff1','4454','First debuff casted by #peqzone Default is Cursed Keepers Blight.'),(1,'Zone:PEQZoneReuseTime','300','Amount of time, in seconds, before you can reuse the #peqzone command'),(1,'Pathing:AggroReturnToGrid','true',''),(1,'Pathing:CandidateNodeRangeXY','400.000000',''),(1,'Pathing:Aggro','true',''),(1,'Adventure:DistanceForRescueComplete','2500.0',''),(1,'Adventure:NumberKillsForBossSpawn','40',''),(1,'Adventure:DistanceForRescueAccept','10000.0',''),(1,'Adventure:MaxNumberForRaid','36',''),(1,'Adventure:MaxLevelRange','9',''),(1,'Adventure:MaxNumberForGroup','6',''),(1,'Adventure:MinNumberForRaid','18',''),(1,'Adventure:MinNumberForGroup','2',''),(1,'Adventure:ItemIDToEnablePorts','41000',''),(1,'Character:KillsPerGroupLeadershipAA','250',''),(1,'Character:KillsPerRaidLeadershipAA','250',''),(1,'Character:YellowModifier','125',''),(1,'Character:RedModifier','150',''),(1,'Character:WhiteModifier','100',''),(1,'Character:LightBlueModifier','40',''),(1,'Character:BlueModifier','90',''),(1,'Combat:NPCBonusHitChance','26.0','notation'),(1,'Character:UseXPConScaling','true',''),(1,'Zone:UsePEQZoneDebuffs','false','Will determine if #peqzone will debuff players or not when used.'),(1,'Character:RestRegenTimeToActivate','30000','Time in seconds for rest state regen to kick in.'),(1,'Character:RestRegenPercent','0','Set to >0 to enable rest state bonus HP and mana regen.'),(1,'Character:RaidExpMultiplier','0.2','notation'),(1,'World:MinGMAntiHackStatus','11','Minimum GM status to check against AntiHack list'),(1,'Chat:KarmaUpdateIntervalMS','1200000','notation'),(1,'Character:GroupExpMultiplier','0.65','notation'),(1,'Chat:MaxMessagesBeforeKick','20','notation'),(1,'Chat:IntervalDurationMS','60000','notation'),(1,'Chat:MinimumMessagesPerInterval','4','notation'),(1,'Chat:MaximumMessagesPerInterval','12','notation'),(1,'Chat:MinStatusToBypassAntiSpam','80','notation'),(1,'Chat:EnableMailKeyIPVerification','true','notation'),(1,'Chat:EnableAntiSpam','true','notation'),(1,'Combat:WeaponSkillFalloff','0.33',''),(1,'Combat:ArcheryHitPenalty','0.45','Archery has a hit penalty to try to help balance it with the plethora of long term +hit modifiers for it'),(1,'Combat:HitBonusPerLevel','1.2',''),(1,'Combat:HitFalloffMajor','50.0',''),(1,'Combat:HitFalloffModerate','7.0','hit will fall off up to 7% over the three levels after the initial level range'),(1,'Combat:HitFalloffMinor','5.0','hit will fall off up to 5% over the initial level range'),(1,'Merchant:ChaPenaltyMod','1.52','Determines CHA bottom:up to 102 CHA. 1.52 is 37 CHA at apprehensive. 0.98 is 0 CHA at apprehensive.'),(1,'Merchant:ChaBonusMod','3.45','Determines CHA cap:from 104 CHA. 3.45 is 132 CHA at apprehensive. 0.34 is 400 CHA at apprehensive.'),(1,'Merchant:PricePenaltyPct','4','Determines maximum price penalty from having bad faction/CHA. Value is a percent.'),(1,'Merchant:PriceBonusPct','4','Determines maximum price bonus from having good faction/CHA. Value is a percent.'),(1,'Merchant:BuyCostMod','0.95','Modifier for NPC buy price.'),(1,'Merchant:SellCostMod','1.05','Modifier for NPC sell price.'),(1,'Merchant:UsePriceMod','true','Use faction/charisma price modifiers.'),(1,'World:GMAccountIPList','false','Check ip list against GM Accounts:AntiHack GM Accounts.'),(1,'Character:AAExpMultiplier','0.65','notation'),(1,'EventLog:RecordBuyFromMerchant','false','Record purchases by a player from an NPC merchant in eventlog table'),(1,'EventLog:RecordSellToMerchant','false','Record sales from a player to an NPC merchant in eventlog table'),(1,'Chat:EnableVoiceMacros','true','notation'),(1,'Spells:TranslocateTimeLimit','0','If not zero:time in seconds to accept a Translocate.'),(1,'Channels:DeleteTimer','1440','Empty password protected channels will be deleted after this many minutes'),(1,'Channels:RequiredStatusListAll','251','Required status to list all chat channels'),(1,'Channels:RequiredStatusAdmin','251','Required status to administer chat channels'),(1,'Mail:ExpireUnread','31536000','1 Year. Set to -1 for never'),(1,'Mail:ExpireRead','31536000','1 Year. Set to -1 for never'),(1,'Mail:ExpireTrash','0','Time in seconds. 0 will delete all messages in the trash when the mailserver starts'),(1,'Mail:EnableMailSystem','true','If false:client wont bring up the Mail window.'),(1,'Bazaar:MaxBarterSearchResults','200','The max results returned in the /barter search'),(1,'Bazaar:EnableWarpToTrader','true','notation'),(1,'World:TutorialZoneID','189','notation'),(1,'Bazaar:MaxSearchResults','200','notation'),(1,'Bazaar:AuditTrail','true','notation'),(1,'World:ExemptAccountLimitStatus','200','Min status required to be exempt from multi-session per account limiting (-1 is disabled)'),(1,'World:AccountSessionLimit','1','Max number of characters allowed on at once from a single account (-1 is disabled)'),(1,'Character:BindAnywhere','false','notation'),(1,'Character:UseDeathExpLossMult','false','Adjust to use the above multiplier or to use code default.'),(1,'Character:DeathExpLossMultiplier','3','Adjust how much exp is lost'),(1,'Combat:BaseHitChance','69','notation'),(1,'Combat:AgiHitFactor','0.01','notation'),(1,'Spells:ResistPerLevelDiff','85','8.5 resist per level difference.'),(1,'Character:SharedBankPlat','true','off by default to prevent duping for now'),(1,'Spells:WizCritChance','5',''),(1,'Spells:WizCritRatio','0',''),(1,'Spells:WizCritLevel','12','level wizards first get spell crits'),(1,'Spells:BaseCritRatio','100','base % bonus to damage on a successful spell crit. 100 = 2x damage'),(1,'Spells:BaseCritChance','0','base % chance that everyone has to crit a spell'),(1,'Combat:BaseProcChance','0.035','notation'),(1,'Combat:ProcDexDivideBy','11000','notation'),(1,'Combat:AvgProcsPerMinute','2.0','notation'),(1,'Combat:ProcPerMinDexContrib','0.075','notation'),(1,'Chat:ServerWideAuction','true','notation'),(1,'Combat:AdjustProcPerMinute','true','notation'),(1,'Chat:ServerWideOOC','true','notation'),(1,'Character:MaxExpLevel','65','Sets the Max Level attainable via Experience'),(1,'Zone:AutoShutdownDelay','5000',''),(1,'World:ClearTempMerchantlist','false','cavedude: Clears temp merchant items when world boots.'),(1,'World:AddMaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < ExemptMaxClientsStatus.  Default value: -1 (feature disabled)'),(1,'World:EnableReturnHomeButton','true','notation'),(1,'World:MaxLevelForTutorial','15','notation'),(1,'World:MinOfflineTimeToReturnHome','21600','21600 seconds is 6 Hours'),(1,'World:AddMaxClientsStatus','-1','Accounts with status >= this rule will be allowed to use the amount of accounts defined in the AddMaxClientsPerIP.  Default value: -1 (feature disabled)'),(1,'TaskSystem:KeepOneRecordPerCompletedTask','true','notation'),(1,'TaskSystem:EnableTaskProximity','true','notation'),(1,'World:EnableTutorialButton','true','notation'),(1,'TaskSystem:RecordCompletedOptionalActivities','true','notation'),(1,'TaskSystem:PeriodicCheckTimer','5',''),(1,'TaskSystem:RecordCompletedTasks','true','notation'),(1,'TaskSystem:EnableTaskSystem','true','Globally enable or disable the Task system'),(2,'Character:RespawnFromHover','false','Enable Respawn Window for SoF and later clients.'),(2,'Character:RespawnFromHoverTimer','300','Respawn Window Timer in Seconds.'),(2,'Spells:EnableBlockedBuffs','true',''),(1,'Character:SkillUpModifier','100','skill ups are at 100%'),(2,'Combat:WarriorThreatBonus','0',''),(2,'Combat:NPCBashKickStunChance','15','Percent chance that a bash/kick will stun'),(1,'NPC:EnableNPCQuestJournal','true','notation'),(1,'NPC:CorpseUnlockTimer','150000','notation'),(1,'NPC:EmptyNPCCorpseDecayTimeMS','6000','notation'),(1,'Spells:PartialHitChanceFear','0.25','The chance when a fear spell is resisted that it will partial hit.'),(2,'Character:ItemEnduranceRegenCap','15','Endurance cap from items'),(2,'Character:ItemClairvoyanceCap','250','Clairvoyance returns mana after a cast under certain circumstances'),(2,'Character:ItemHealAmtCap','250','Heal Amt adds to heal spells based on their cast & recast time'),(2,'Character:ItemSpellDmgCap','250','Spell Dmg adds to DD spells based on their cast & recast time'),(2,'Character:ItemDSMitigationCap','50','Mitigates the effect of a damage shield'),(2,'Character:UseNewStatsWindow','true','New stats window shows so much it got the TSA seal of approval'),(1,'World:UseBannedIPsTable','true','Toggle whether or not to check incoming client connections against the Banned_IPs table. Set this value to false to disable this feature.'),(1,'Zone:MQWarpExemptStatus','80',''),(2,'Spells:ReflectType','1','0 = disabled, 1 = single target player spells only, 2 = all player spells, 3 = all single target spells, 4 = all spells'),(1,'Character:ItemStrikethroughCap','35','notation'),(1,'Zone:MQWarpDetectionDistanceFactor','9.0',''),(2,'Character:HasteCap','100','Haste cap for item haste + spell haste(not including overhaste)'),(2,'Character:MaxDraggedCorpses','2','Maximum number of corpses that a player can /corpsedrag at once'),(2,'Character:DragCorpseDistance','400.000000','If a player is using /corpsedrag and moving, the corpse will not move until the player exceeds this distance (NoRootNoZ)'),(2,'Character:RestRegenEndurance','false','Whether rest regen will affect endurance or not'),(2,'Character:CorpseResTimeMS','10800000','Time to res a corpse(ms)'),(2,'Spells:VirusSpreadDistance','30','The distance a viral spell will jump to its next victim'),(2,'Character:ItemCastsUseFocus','false','If true, this allows item clickies to use focuses that have limited max levels on them'),(2,'Character:CheckCursorEmptyWhenLooting','true','If true, a player cannot loot a corpse (player or NPC) with an item on their cursor'),(2,'World:ExpansionSettings','16383','Expansion settings. Affects client features related to expansions.'),(2,'World:PVPSettings','0','PVP Settings, affects clients\' attack state and Sony-hardcoded checks for PVP rules.'),(2,'World:IsGMPetitionWindowEnabled','false',''),(2,'World:FVNoDropFlag','0','Sets the FV ruleset to on or off. Enable with rule 2 for GM-trading only. Keep in mind this disables OOC chatter for GMs only if you choose that option.'),(2,'Character:MinStatusForNoDropExemptions','80','Enables bypassing of no-drop flags if status is set to this value and FVNoDropFlag is set to 2.'),(2,'Character:SkillCapMaxLevel','-1','Sets the Max Level used for Skill Caps (from skill_caps table).  Default of -1 makes it use MaxLevel rule value.'),(2,'Character:StatCap','0','Sets the Max Statistics Cap for PCs. 0 = feature disabled'),(2,'Character:MaintainIntoxicationAcrossZones','true','If true, alcohol effects are maintained across zoning and logging out/in.'),(1,'Character:ItemDoTShieldingCap','35','notation'),(1,'Character:ItemStunResistCap','35','notation'),(2,'Skills:MaxTrainSpecializations','50','Max level a GM trainer will train casting specializations'),(2,'Combat:ArcheryNPCMultiplier','1.0','Multiplied by the min and max hit to determine npcs ranged dmg'),(2,'Console:SessionTimeOut','600000','This sets the default timeout time for Telnet sessions (MS)'),(2,'Guild:PlayerCreationAllowed','true','Allow players with Underfoot+ to create a guild via new UI window.'),(2,'Guild:PlayerCreationLimit','1','Allow players to create a guild using the window in Underfoot+'),(2,'Guild:PlayerCreationRequiredLevel','0','Required level to use the UF+ window to create a new guild.'),(2,'Guild:PlayerCreationRequiredStatus','0','Required admin status to use UF+ window to create a new guild.'),(2,'Guild:PlayerCreationRequiredTime','0','Required Time Entitled on Account to be able to use UF+ window to create a new guild.'),(2,'Spells:LiveLikeFocusEffects','true','Makes certain healing, dmg and mana reduction focuses random like live'),(2,'NPC:StartEnrageValue','9','% HP value that mobs will begin to enrage.'),(2,'NPC:LiveLikeEnrage','false','If enabled, will cause all non-player pets to lose the ability to enrage.'),(2,'Character:ItemExtraDmgCap','150','eg +bash, +frenzy dmg, etc'),(2,'Bots:BotAAExpansion','8','The expansion through which bots will obtain AAs'),(1,'Character:ItemSpellShieldingCap','35','notation'),(1,'Character:ItemCombatEffectsCap','100','notation'),(1,'Character:ItemShieldingCap','35','notation'),(1,'Character:ItemAccuracyCap','150','notation'),(1,'Character:ItemAvoidanceCap','100','notation'),(1,'Zone:MQZoneExemptStatus','80',''),(1,'Character:ItemDamageShieldCap','30','notation'),(1,'Zone:MQGhostExemptStatus','80',''),(1,'Zone:MQGateExemptStatus','80',''),(1,'Zone:EnableMQWarpDetector','true',''),(1,'Combat:FleeIfNotAlone','false',''),(1,'Zone:EnableMQZoneDetector','true',''),(1,'Zone:EnableMQGateDetector','true',''),(1,'World:MaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < AddMaxClientsStatus.  Default value: -1 (feature disabled)'),(1,'Aggro:PetSpellAggroMod','10','notation'),(1,'Character:DeathItemLossLevel','10','notation'),(1,'Zone:EnableMQGhostDetector','true',''),(1,'NPC:BuffFriends','false','notation'),(1,'Aggro:SpellAggroMod','100','notation'),(1,'Aggro:SongAggroMod','33','notation'),(1,'Combat:AssistNoTargetSelf','false','When assisting a target without a target: true = target self, false = leave target as was before assist (this is the behavior on live)'),(1,'Aggro:CriticallyWoundedAggroMod','100','notation'),(1,'Aggro:CurrentTargetAggroMod','0','0 will prefer our current target to any other, > 0 makes it harder for our npcs to switch targets.'),(1,'Aggro:SittingAggroMod','35','notation'),(1,'Aggro:MeleeRangeAggroMod','20','notation'),(1,'Aggro:SmartAggroList','true','notation'),(1,'Watermap:FishingLineLength','40','If water is more than this far below the player:it is considered too far to fish'),(1,'Watermap:FishingRodLength','30','How far in front of player water must be for fishing to work'),(1,'Watermap:CheckForWaterWhenFishing','true','Only lets a player fish near water (if a water map exists for the zone)'),(1,'Watermap:CheckForWaterOnSendTo','false','Checks if a mob has moved into/out of water on SendTo'),(1,'Watermap:CheckForWaterAtWaypoints','true',''),(1,'Watermap:CheckForWaterWhenMoving','true',''),(1,'NPC:OOCRegen','1','notation'),(1,'Watermap:CheckWaypointsInWaterWhenLoading','true',''),(1,'NPC:SayPauseTimeInSec','10','notation'),(2,'Character:UseRaceClassExpBonuses','true','Setting this to true will enable Class and Racial experience rate bonuses'),(1,'Combat:UseIntervalAC','true',''),(1,'Combat:PetAttackMagicLevel','30',''),(2,'Character:EnableDiscoveredItems','false','If enabled, it enables EVENT_DISCOVER_ITEM and also saves character names and timestamps'),(1,'Character:ItemManaRegenCap','15','notation'),(1,'Character:ItemHealthRegenCap','15','notation'),(2,'Character:SumCorpseDecayTimeMS','43200000',''),(1,'Character:HealOnLevel','false','notation'),(1,'Character:FeignKillsPet','false','notation'),(1,'Map:FixPathingZMaxDeltaWaypoint','20',''),(2,'World:DeleteStaleCorpeBackups','true','Deletes stale corpse backups older than 2 weeks.'),(2,'Zone:UsePlayerCorpseBackups','true','Keeps backups of player corpses.'),(2,'Character:EnableXTargetting','true',''),(2,'Spells:AvgSpellProcsPerMinute','6.0','Default = 6.0 Determines proc rate of spells applied from sympathetic focus effect'),(2,'Spells:ResistFalloff','67','Default = 67 Max that level that will adjust our resist chance based on level modifiers'),(2,'Spells:CharismaEffectiveness','10','Default 10 CHA = -1 resist mod. Deterimes how much resist modification charisma applies to charm/pacify checks.'),(2,'Spells:CharmBreakCheckChance','25','Default 25. Determines percent chance for a charm break check to occur each buff tick.'),(2,'Combat:AvgDefProcsPerMinute','2','Default 2. Determines defensive procs per minute.'),(2,'Combat:DefProcPerMinAgiContrib','0.075','Default 25. Determines how much agility effects proc rate.'),(2,'Combat:SpecialAttackACBonus','15','(Default=15) Percent amount of damage per AC gained for certain special attacks (damage = AC*SpecialAttackACBonus/100).'),(1,'Map:FixPathingZMaxDeltaLoading','20',''),(1,'Map:FixPathingZMaxDeltaMoving','20',''),(1,'Zone:ClientLinkdeadMS','180000',''),(1,'Map:FixPathingZMaxDeltaSendTo','20',''),(1,'Map:FixPathingZAtWaypoints','true',''),(1,'Map:FixPathingZWhenMoving','true',''),(1,'Map:FixPathingZOnSendTo','false',''),(1,'Zone:GraveyardTimeMS','1200000',''),(1,'Map:FixPathingZWhenLoading','true',''),(1,'Zone:EnableShadowrest','1',''),(1,'NPC:UseItemBonusesForNonPets','true','notation'),(1,'Character:ExpMultiplier','0.65','notation'),(1,'NPC:MinorNPCCorpseDecayTimeMS','600000','level<55'),(1,'NPC:MajorNPCCorpseDecayTimeMS','1800000','level>=55'),(2,'Combat:FrenzyBonus','0','Modify Frenzy skill damage by percent,'),(1,'Zone:NPCPositonUpdateTicCount','32','ms between intervals of sending a position update to the entire zone.'),(2,'Combat:TauntSkillFalloff','0.33','(Default=0.33) For every taunt skill point thats not maxed you lose this % chance to taunt.'),(1,'Combat:ClientBaseCritChance','0',''),(1,'Spells:PartialHitChance','0.7','The chance when a spell is resisted that it will partial hit.'),(1,'Spells:ResistMod','0.40','multiplier:chance to resist = this * ResistAmount'),(2,'Spells:MaxCastTimeReduction','50','Max percent your spell cast time can be reduced by spell haste.'),(2,'Spells:RootBreakFromSpells','55','Chance for root to break when cast on.'),(2,'Spells:DeathSaveCharismaMod','3','Determines how much charisma effects chance of death save firing.(CHA*value/10)'),(2,'Spells:DivineInterventionHeal','8000','Divine intervention heal amount.'),(2,'Combat:NPCFlurryChance','20','(Default=20) Chance for NPC to flurry if special attack F '),(1,'Spells:AutoResistDiff','15','notation'),(1,'Spells:ResistChance','2.0','chance to resist given no resists and same level'),(2,'AA:Stacking','true','Enable stacking of AA within the same series on all clients'),(1,'Character:ConsumptionMultiplier','100',''),(1,'Combat:BerserkBaseCritChance','6',''),(1,'Combat:NPCBashKickLevel','6',''),(2,'Spells:AdditiveBonusValues','false','Allow certain bonuses to be calculated by adding together the value from each item, instead of taking the highest value. (ie Add together all Cleave Effects)'),(2,'Character:PerCharacterQglobalMaxLevel','false','Allows Character Max Level based on qglobal \"CharMaxLevel'),(1,'Combat:WarBerBaseCritChance','3','The base crit chance for warriors and berserkers:only applies to clients'),(2,'QueryServ:PlayerLogNPCKills','false',''),(2,'QueryServ:PlayerLogTrades','false',''),(2,'QueryServ:PlayerChatLogging','false',''),(2,'QueryServ:PlayerLogMoneyTrades','false',''),(2,'QueryServ:PlayerLogPCCoordinates','false',''),(1,'Combat:MeleeBaseCritChance','0','The base crit chance for non warriors:NOTE: This will apply to NPCs as well'),(1,'Combat:EnableFearPathing','true',''),(2,'Chat:FlowCommandstoPerl_EVENT_SAY','true',''),(2,'World:IPLimitDisconnectAll','false','Disconnect all current clients by IP if they go over the IP limit.  This should allow people to quickly reconnect in the case of dead sessions waiting to timeout.'),(1,'Combat:FleeHPRatio','21',''),(1,'World:ExemptMaxClientsStatus','-1','Exempt accounts from the MaxClientsPerIP and AddMaxClientsStatus rules:if their status is >= this value.  Default value: -1 (feature disabled)'),(1,'World:ZoneAutobootTimeoutMS','120000','notation'),(1,'World:ClientKeepaliveTimeoutMS','95000','notation'),(2,'Pets:UnTargetableSwarmPet','false','Set true to allow swarm pets to not be targeted by clients.'),(2,'QueryServ:MerchantLogTransactions','false',''),(2,'QueryServ:PlayerLogDeletes','false',''),(2,'QueryServ:PlayerLogHandins','false',''),(2,'QueryServ:PlayerLogMoves','false',''),(1,'Pets:AttackCommandRange','200','Range at which a pet will respond to attack commands'),(1,'Skills:MaxTrainTradeskills','21','Highest skill level that tradeskills can be trained to from GM Trainers'),(1,'Guild:MaxMembers','2048','Max number of members allowed in a single guild'),(1,'Character:EnduranceRegenMultiplier','100','notation'),(1,'Character:ManaRegenMultiplier','100','notation'),(1,'Character:HPRegenMultiplier','100','notation'),(1,'Character:AutosaveIntervalS','300','0=disabled'),(1,'Character:LeaveNakedCorpses','true','notation'),(1,'Character:DeathExpLossLevel','10','notation'),(1,'Character:CorpseDecayTimeMS','43200000','notation'),(3,'Mercs:AllowMercs','false',''),(1,'GM:MinStatusToZoneAnywhere','250','This setting overrides the minstatus setting in the zones table if set'),(1,'Character:MaxLevel','65','notation'),(1,'Character:LeaveCorpses','true','notation'),(2,'Mercs:AllowMercs','false','Turns mercs on for the server - will not load merc data if set to false.'),(2,'Mercs:SuspendIntervalMS','10000','Time interval for suspend command in milliseconds.'),(2,'Mercs:UpkeepIntervalMS','180000','Time interval for merc upkeep in milliseconds.'),(2,'Mercs:SuspendIntervalS','10','Time interval for suspend command in seconds.'),(2,'Mercs:UpkeepIntervalS','180','Time interval for merc upkeep in seconds.'),(2,'Mercs:ScaleRate','100','Allows scaling of merc stats vs livelike values.'),(2,'Mercs:AggroRadius','100','Determines the distance from which a merc will aggro target(also used to determine the distance at which a healer merc will begin healing a group member)'),(2,'Mercs:AggroRadiusPuller','25','Determines the distance from which a merc will aggro target, if they have the group role of puller (also used to determine the distance at which a healer merc will begin healing a group member, if they have the group role of puller)'),(1,'Character:HasteCap','100','Haste cap for item haste + spell haste(not including overhaste)'),(1,'Character:MaxDraggedCorpses','2','Maximum number of corpses that a player can /corpsedrag at once'),(1,'Character:DragCorpseDistance','400.000000','If a player is using /corpsedrag and moving, the corpse will not move until the player exceeds this distance (NoRootNoZ)'),(1,'Character:RestRegenEndurance','false','Whether rest regen will affect endurance or not'),(1,'Spells:VirusSpreadDistance','30','The distance a viral spell will jump to its next victim'),(1,'Combat:ArcheryNPCMultiplier','1.0','Multiplied by the min and max hit to determine npcs ranged dmg'),(1,'Character:ItemCastsUseFocus','false','If true, this allows item clickies to use focuses that have limited max levels on them'),(1,'World:ExpansionSettings','16383','Expansion settings. Affects client features related to expansions.'),(1,'World:PVPSettings','0','PVP Settings, affects clients\' attack state and Sony-hardcoded checks for PVP rules.'),(1,'World:FVNoDropFlag','0','Sets the FV ruleset to on or off. Enable with rule 2 for GM-trading only. Keep in mind this disables OOC chatter for GMs only if you choose that option.'),(1,'Character:MinStatusForNoDropExemptions','80','Enables bypassing of no-drop flags if status is set to this value and FVNoDropFlag is set to 2.'),(1,'Character:SkillCapMaxLevel','-1','Sets the Max Level used for Skill Caps (from skill_caps table).  Default of -1 makes it use MaxLevel rule value.'),(1,'Console:SessionTimeOut','600000','This sets the default timeout time for Telnet sessions (MS)'),(1,'Guild:PlayerCreationAllowed','true','Allow players with Underfoot+ to create a guild via new UI window.'),(1,'Guild:PlayerCreationLimit','1','Allow players to create a guild using the window in Underfoot+'),(1,'Guild:PlayerCreationRequiredLevel','0','Required level to use the UF+ window to create a new guild.'),(1,'Guild:PlayerCreationRequiredStatus','0','Required admin status to use UF+ window to create a new guild.'),(1,'Guild:PlayerCreationRequiredTime','0','Required Time Entitled on Account to be able to use UF+ window to create a new guild.'),(1,'Spells:LiveLikeFocusEffects','true','Makes certain healing, dmg and mana reduction focuses random like live'),(1,'NPC:StartEnrageValue','9','% HP value that mobs will begin to enrage.'),(1,'NPC:LiveLikeEnrage','false','If enabled, will cause all non-player pets to lose the ability to enrage.'),(1,'Character:ItemExtraDmgCap','150','eg +bash, +frenzy dmg, etc'),(1,'Character:CheckCursorEmptyWhenLooting','true','If true, a player cannot loot a corpse (player or NPC) with an item on their cursor'),(1,'Character:MaintainIntoxicationAcrossZones','true','If true, alcohol effects are maintained across zoning and logging out/in.'),(1,'Bots:BotAAExpansion','8','The expansion through which bots will obtain AAs'),(1,'Character:UseRaceClassExpBonuses','true','Setting this to true will enable Class and Racial experience rate bonuses'),(1,'Character:EnableDiscoveredItems','false','If enabled, it enables EVENT_DISCOVER_ITEM and also saves character names and timestamps'),(1,'Combat:WarriorThreatBonus','0',''),(1,'Character:CorpseResTimeMS','10800000','Time to res a corpse(ms)'),(1,'Character:StatCap','0','Sets the Max Statistics Cap for PCs. 0 = feature disabled'),(1,'Character:SumCorpseDecayTimeMS','43200000',''),(1,'World:DeleteStaleCorpeBackups','true','Deletes stale corpse backups older than 2 weeks.'),(1,'Zone:UsePlayerCorpseBackups','true','Keeps backups of player corpses.'),(1,'Character:EnableXTargetting','true',''),(1,'Spells:AvgSpellProcsPerMinute','6.0','Default = 6.0 Determines proc rate of spells applied from sympathetic focus effect'),(1,'Spells:ResistFalloff','67','Default = 67 Max that level that will adjust our resist chance based on level modifiers'),(1,'Spells:CharismaEffectiveness','10','Default 10 CHA = -1 resist mod. Deterimes how much resist modification charisma applies to charm/pacify checks.'),(1,'Spells:CharmBreakCheckChance','25','Default 25. Determines percent chance for a charm break check to occur each buff tick.'),(1,'Combat:AvgDefProcsPerMinute','2','Default 2. Determines defensive procs per minute.'),(1,'Combat:DefProcPerMinAgiContrib','0.075','Default 25. Determines how much agility effects proc rate.'),(1,'Combat:SpecialAttackACBonus','15','(Default=15) Percent amount of damage per AC gained for certain special attacks (damage = AC*SpecialAttackACBonus/100).'),(1,'Combat:FrenzyBonus','0','Modify Frenzy skill damage by percent,'),(1,'Combat:TauntSkillFalloff','0.33','(Default=0.33) For every taunt skill point thats not maxed you lose this % chance to taunt.'),(1,'Spells:MaxCastTimeReduction','50','Max percent your spell cast time can be reduced by spell haste.'),(1,'Spells:RootBreakFromSpells','55','Chance for root to break when cast on.'),(1,'Spells:DeathSaveCharismaMod','3','Determines how much charisma effects chance of death save firing.(CHA*value/10)'),(1,'Spells:DivineInterventionHeal','8000','Divine intervention heal amount.'),(1,'Combat:NPCFlurryChance','20','(Default=20) Chance for NPC to flurry if special attack F '),(1,'AA:Stacking','true','Enable stacking of AA within the same series on all clients'),(1,'Spells:AdditiveBonusValues','false','Allow certain bonuses to be calculated by adding together the value from each item, instead of taking the highest value. (ie Add together all Cleave Effects)'),(1,'Character:PerCharacterQglobalMaxLevel','false','Allows Character Max Level based on qglobal \"CharMaxLevel'),(1,'QueryServ:PlayerLogNPCKills','false',''),(1,'QueryServ:PlayerLogTrades','false',''),(1,'QueryServ:PlayerChatLogging','false',''),(1,'QueryServ:PlayerLogMoneyTrades','false',''),(1,'QueryServ:PlayerLogPCCoordinates','false',''),(1,'Chat:FlowCommandstoPerl_EVENT_SAY','true',''),(1,'World:IPLimitDisconnectAll','false','Disconnect all current clients by IP if they go over the IP limit.  This should allow people to quickly reconnect in the case of dead sessions waiting to timeout.'),(1,'Pets:UnTargetableSwarmPet','false','Set true to allow swarm pets to not be targeted by clients.'),(1,'QueryServ:MerchantLogTransactions','false',''),(1,'QueryServ:PlayerLogDeletes','false',''),(1,'QueryServ:PlayerLogHandins','false',''),(1,'QueryServ:PlayerLogMoves','false',''),(1,'Mercs:AllowMercs','false','Turns mercs on for the server - will not load merc data if set to false.'),(1,'Mercs:SuspendIntervalMS','10000','Time interval for suspend command in milliseconds.'),(1,'Mercs:UpkeepIntervalMS','180000','Time interval for merc upkeep in milliseconds.'),(1,'Mercs:SuspendIntervalS','10','Time interval for suspend command in seconds.'),(1,'Mercs:UpkeepIntervalS','180','Time interval for merc upkeep in seconds.'),(1,'Mercs:ScaleRate','100','Allows scaling of merc stats vs livelike values.'),(1,'Mercs:AggroRadius','100','Determines the distance from which a merc will aggro target(also used to determine the distance at which a healer merc will begin healing a group member)'),(1,'Mercs:AggroRadiusPuller','25','Determines the distance from which a merc will aggro target, if they have the group role of puller (also used to determine the distance at which a healer merc will begin healing a group member, if they have the group role of puller)'),(10,'Combat:MaxFlurryHits','2','max number of extra hits from flurry'),(10,'Combat:MonkDamageTableBonus','5','% bonus monks get to their damage table calcs'),(10,'Combat:RampageHitsTarget','false','rampage will hit the target if it still has targets left'),(10,'Combat:DefaultRampageTargets','1','default number of people to hit with rampage'),(10,'Combat:MaxRampageTargets','3','max number of people hit with rampage'),(10,'Combat:AssistNoTargetSelf','true','when assisting a target that does not have a target: true = target self,false = leave target as was before assist (false = live like)'),(10,'Combat:ArcheryNPCMultiplier','1.0','this is multiplied by the regular dmg to get the archery dmg'),(10,'Combat:ArcheryBaseDamageBonus','1','% Modifier to Base Archery Damage (5 = 50% base damage,1 = 100%,2 = 200%)'),(10,'Combat:ArcheryBonusRequiresStationary','true','does the 2x archery bonus chance require a stationary npc'),(10,'Combat:MinRangedAttackDist','25','Minimum Distance to use Ranged Attacks'),(10,'Combat:AgiHitFactor','0.01',''),(10,'Combat:ArcheryHitPenalty','0.25','Archery has a hit penalty to try to help balance it with the plethora of long term +hit modifiers for it'),(10,'Combat:WeaponSkillFalloff','0.33','For every weapon skill point thats not maxed you lose this % of hit'),(10,'Combat:HitBonusPerLevel','1.2','You gain this % of hit for every level you are above your target'),(10,'Combat:HitFalloffMajor','50.0','hit will fall off sharply if were outside the minor and moderate range'),(10,'Combat:HitFalloffModerate','7.0','hit will fall off up to 7% over the three levels after the initial level range'),(10,'Combat:HitFalloffMinor','5.0','hit will fall off up to 5% over the initial level range'),(10,'Combat:NPCBonusHitChance','26.0',''),(10,'Combat:BaseHitChance','69.0',''),(10,'Combat:ProcDexDivideBy','11000',''),(10,'Combat:BaseProcChance','0.035',''),(10,'Combat:ProcPerMinDexContrib','0.075',''),(10,'Combat:AdjustProcPerMinute','true',''),(10,'Combat:AvgProcsPerMinute','2.0',''),(10,'Combat:FleeIfNotAlone','false','If false,mobs wont flee if other mobs are in combat with it.'),(10,'Combat:FleeHPRatio','25','HP % when a NPC begins to flee.'),(10,'Combat:EnableFearPathing','true',''),(10,'Combat:FleeMultiplier','2.0','Determines how quickly a NPC will slow down while fleeing. Decrease multiplier to slow NPC down quicker.'),(10,'Combat:UseIntervalAC','true',''),(10,'Combat:PetAttackMagicLevel','30',''),(10,'Combat:ClientBaseCritChance','0','The base crit chance for all clients,this will stack with warriors/zerkers crit chance.'),(10,'Combat:NPCBashKickStunChance','15','Percent chance that a bash/kick will stun'),(10,'Combat:NPCBashKickLevel','6','The level that npcs can KICK/BASH'),(10,'Combat:BerserkBaseCritChance','6','The bonus base crit chance you get when youre berserk'),(10,'Combat:WarBerBaseCritChance','3','The base crit chance for warriors and berserkers,only applies to clients'),(10,'Combat:MeleeBaseCritChance','0','The base crit chance for non warriors ,NOTE: This will apply to NPCs as well'),(10,'Spells:BuffLevelRestrictions','true','Buffs will not land on low level toons like live'),(10,'Spells:UseCHAScribeHack','false','ScribeSpells and TrainDiscs quest functions will ignore entries where field 12 is CHA.  Whats the best way to do this?'),(10,'Spells:AdditiveBonusValues','false','Allow certain bonuses to be calculated by adding together the value from each item,instead of taking the highest value. (ie Add together all Cleave Effects)'),(10,'Spells:RootBreakFromSpells','55','Chance for root to break when cast on.'),(10,'Spells:DeathSaveCharismaMod','3','Determines how much charisma effects chance of death save firing.'),(10,'Spells:DivineInterventionHeal','8000','Divine intervention heal amount.'),(10,'Spells:MaxCastTimeReduction','50','Max percent your spell cast time can be reduced by spell haste'),(10,'Spells:CharmBreakCheckChance','25','Determines chance for a charm break check to occur each buff tick.'),(10,'Spells:CharismaCharmDuration','false','Allow CHA resist mod to extend charm duration.'),(10,'Spells:CharismaEffectivenessCap','200','Deterimes how much resist modification charisma applies to charm/pacify checks. Default 10 CHA = -1 resist mod.'),(10,'Spells:CharismaEffectiveness','10','Deterimes how much resist modification charisma applies to charm/pacify checks. Default 10 CHA = -1 resist mod.'),(10,'Spells:AvgSpellProcsPerMinute','6.0','Adjust rate for sympathetic spell procs'),(10,'Spells:ResistFalloff','67','Max that level that will adjust our resist chance based on level modifiers'),(10,'Spells:BaseImmunityLevel','55','The level that targets start to be immune to stun,fear and mez spells with a max level of 0.'),(10,'Spells:NPCIgnoreBaseImmunity','true','Whether or not NPCs get to ignore the BaseImmunityLevel for their spells.'),(10,'Spells:LiveLikeFocusEffects','true','Determines whether specific healing,dmg and mana reduction focuses are randomized'),(10,'Spells:VirusSpreadDistance','30','The distance a viral spell will jump to its next victim'),(10,'Spells:ReflectType','1','0 = disabled,1 = single target player spells only,2 = all player spells,3 = all single target spells,4 = all spells'),(10,'Spells:EnableBlockedBuffs','true',''),(10,'Spells:MaxTotalSlotsPET','25','do not set this higher than 25 until the player profile is removed from the blob'),(10,'Spells:MaxDiscSlotsNPC','1',''),(10,'Spells:MaxTotalSlotsNPC','36',''),(10,'Spells:MaxSongSlotsNPC','10',''),(10,'Spells:MaxBuffSlotsNPC','25',''),(10,'Spells:EnableSpellGlobals','false','If Enabled,spells check the spell_globals table and compare character data from the quest globals before allowing that spell to scribe with scribespells'),(10,'Spells:SacrificeItemID','9963','Item ID of the item Sacrifice will return (defaults to an EE)'),(10,'Spells:SacrificeMaxLevel','69','last level Sacrifice will work on'),(10,'Spells:SacrificeMinLevel','46','first level Sacrifice will work on'),(10,'Spells:ResistPerLevelDiff','85','8.5 resist per level difference.'),(10,'Spells:TranslocateTimeLimit','0','If not zero,time in seconds to accept a Translocate.'),(10,'Spells:WizCritRatio','0','wizs crit bonus,on top of BaseCritRatio (should be 0 for Live-like)'),(10,'Spells:WizCritLevel','12','level wizards first get spell crits'),(10,'Spells:WizCritChance','7','wizs crit chance,on top of BaseCritChance'),(10,'Spells:BaseCritChance','0','base % chance that everyone has to crit a spell'),(10,'Spells:BaseCritRatio','100','base % bonus to damage on a successful spell crit. 100 = 2x damage'),(10,'Spells:PartialHitChanceFear','0.25','The chance when a fear spell is resisted that it will partial hit.'),(10,'Spells:PartialHitChance','0.7','The chance when a spell is resisted that it will partial hit.'),(10,'Spells:ResistMod','0.40','multiplier,chance to resist = this * ResistAmount'),(10,'Spells:ResistChance','2.0','chance to resist given no resists and same level'),(10,'Spells:AutoResistDiff','15',''),(10,'Watermap:FishingLineLength','40',' If water is more than this far below the player,it is considered too far to fish'),(10,'Watermap:FishingRodLength','30',' How far in front of player water must be for fishing to work'),(10,'Watermap:CheckForWaterWhenFishing','false',' Only lets a player fish near water (if a water map exists for the zone)'),(10,'Watermap:CheckForWaterOnSendTo','false',' Checks if a mob has moved into/out of water on SendTo'),(10,'Watermap:CheckForWaterAtWaypoints','false',' Check if a mob has moved into/out of water when at waypoints and sets flymode'),(10,'Watermap:CheckForWaterWhenMoving','false',' Checks if a mob has moved into/out of water each time its loc is recalculated'),(10,'Watermap:CheckWaypointsInWaterWhenLoading','false','Does not apply BestZ as waypoints are loaded if they are in water'),(10,'Pathing:CandidateNodeRangeZ','10',' When searching for path start/end nodes,only nodes within this range will be considered.'),(10,'Pathing:CandidateNodeRangeXY','400',' When searching for path start/end nodes,only nodes within this range will be considered.'),(10,'Pathing:CullNodesFromEnd','1',' Checks LOS from End point to second to last node for this many nodes and removes last node if there is LOS'),(10,'Pathing:CullNodesFromStart','1',' Checks LOS from Start point to second node for this many nodes and removes first node if there is LOS'),(10,'Pathing:MinNodesTraversedForLOSCheck','3','Only check for LOS after we have traversed this many path nodes.'),(10,'Pathing:MinNodesLeftForLOSCheck','4','Only check for LOS when we are down to this many path nodes left to run. This next rule was put in for situations where the mob and its target may be on different sides of a hazard,e.g. a pit If the mob has LOS to its target:even though there is a hazard in its way,it may break off from the node path and run at the target,only to later detect the hazard and re-acquire a node path. Depending upon the placement of the path nodes,this can lead to the mob looping. The rule is intended to allow the mob to at least get closer to its target each time before checking LOS and trying to head straight for it.'),(10,'Pathing:MinDistanceForLOSCheckLong','1000000','(NoRoot). Min distance when initially attempting to acquire the target.'),(10,'Pathing:MinDistanceForLOSCheckShort','40000','(NoRoot). While following a path,only check for LOS to target within this distance.'),(10,'Pathing:RouteUpdateFrequencyNodeCount','5',''),(10,'Pathing:RouteUpdateFrequencyLong','5000','How often a new route will be calculated if the target has moved. When a path has a path node route and its target changes position,if it has RouteUpdateFrequencyNodeCount or less nodes to go on its current path ,it will recalculate its path based on the RouteUpdateFrequencyShort timer,otherwise it will use the RouteUpdateFrequencyLong timer.'),(10,'Pathing:RouteUpdateFrequencyShort','1000','How often a new route will be calculated if the target has moved.'),(10,'Pathing:LOSCheckFrequency','1000','A mob will check for LOS to its target this often (milliseconds)'),(10,'Pathing:Fear','true',' Enable pathing for fear'),(10,'Pathing:ZDiffThreshold','10','If a mob las LOS to its target,it will run to it if the Z difference is < this.'),(10,'Pathing:Find','true',' Enable pathing for FindPerson requests from the client.'),(10,'Pathing:Guard','true',' Enable pathing for mobs moving to their guard point.'),(10,'Pathing:Aggro','true',' Enable pathing for aggroed mobs.'),(10,'Pathing:AggroReturnToGrid','true','Enable pathing for aggroed roaming mobs returning to their previous waypoint.'),(10,'Map:FindBestZHeightAdjust','1',' Adds this to the current Z before seeking the best Z position'),(10,'Map:UseClosestZ','false',' Move mobs to the nearest Z above or below,rather than just the nearest below. Only set UseClosestZ true if all your .map files generated from EQGs were created with azone2.'),(10,'Map:FixPathingZMaxDeltaLoading','45','while loading each waypoint: max change in Z to allow the BestZ code to apply.'),(10,'Map:FixPathingZMaxDeltaSendTo','20','at runtime in SendTo: max change in Z to allow the BestZ code to apply.'),(10,'Map:FixPathingZMaxDeltaWaypoint','20','at runtime at each waypoint: max change in Z to allow the BestZ code to apply.'),(10,'Map:FixPathingZMaxDeltaMoving','20','at runtime while pathing: max change in Z to allow the BestZ code to apply.'),(10,'Map:FixPathingZOnSendTo','false','try to repair Z coords in the SendTo routine as well.'),(10,'Map:FixPathingZWhenMoving','false','very CPU intensive,but helps hopping with widely spaced waypoints.'),(10,'Zone:WeatherTimer','600','Weather timer when no duration is available'),(10,'Map:FixPathingZWhenLoading','true','increases zone boot times a bit to reduce hopping.'),(10,'Map:FixPathingZAtWaypoints','false','alternative to `WhenLoading`,accomplishes the same thing but does it at each waypoint instead of once at boot time.'),(10,'Zone:RadiantCrystalItemID','40903',''),(10,'Zone:LevelBasedEXPMods','false','Allows you to use the level_exp_mods table in consideration to your players EXP hits'),(10,'Zone:EbonCrystalItemID','40902',''),(10,'Zone:PEQZoneReuseTime','900','How long,in seconds,until you can reuse the #peqzone command.'),(10,'Zone:PEQZoneDebuff1','4454','First debuff casted by #peqzone Default is Cursed Keepers Blight.'),(10,'Zone:PEQZoneDebuff2','2209','Second debuff casted by #peqzone Default is Tendrils of Apathy.'),(10,'Zone:UsePEQZoneDebuffs','true','Will determine if #peqzone will debuff players or not when used.'),(10,'Zone:HotZoneBonus','0.75',''),(10,'Zone:ReservedInstances','30','Will reserve this many instance ids for globals... probably not a good idea to change this while a server is running.'),(10,'Zone:MarkMQWarpLT','false',''),(10,'Zone:AutoShutdownDelay','5000','How long a dynamic zone stays loaded while empty'),(10,'Zone:MQWarpDetectionDistanceFactor','9.0','clients move at 4.4 about if in a straight line but with movement and to acct for lag we raise it a bit'),(10,'Zone:EnableMQGhostDetector','true','Enable the MQGhost Detector. Set to false to disable this feature.'),(10,'Zone:EnableMQGateDetector','true','Enable the MQGate Detector. Set to false to disable this feature.'),(10,'Zone:EnableMQZoneDetector','true','Enable the MQZone Detector. Set to false to disable this feature.'),(10,'Zone:EnableMQWarpDetector','true','Enable the MQWarp Detector. Set to false to disable this feature.'),(10,'Zone:MQGhostExemptStatus','-1','Required status level to exempt the MGhostDetector. Set to -1 to disable this feature.'),(10,'Zone:MQGateExemptStatus','-1','Required status level to exempt the MQGateDetector. Set to -1 to disable this feature.'),(10,'Zone:MQZoneExemptStatus','-1','Required status level to exempt the MQZoneDetector. Set to -1 to disable this feature.'),(10,'Zone:MQWarpExemptStatus','-1','Required status level to exempt the MQWarpDetector. Set to -1 to disable this feature.'),(10,'Zone:UsePlayerCorpseBackups','true','Keeps backups of player corpses.'),(10,'Zone:EnableShadowrest','1','enables or disables the shadowrest zone feature for player corpses. Default is turned on.'),(10,'Zone:GraveyardTimeMS','1200000','ms time until a player corpse is moved to a zones graveyard,if one is specified for the zone'),(10,'Zone:ClientLinkdeadMS','180000','the time a client remains link dead on the server after a sudden disconnection'),(10,'Zone:NPCPositonUpdateTicCount','32','ms between intervals of sending a position update to the entire zone.'),(10,'World:IPLimitDisconnectAll','false',''),(10,'World:IsGMPetitionWindowEnabled','false',''),(10,'World:FVNoDropFlag','0','Sets the Firiona Vie settings on the client. If set to 2,the flag will be set for GMs only,allowing trading of no-drop items.'),(10,'World:PVPSettings','0','Sets the PVP settings for the server,1 = Rallos Zek RuleSet,2 = Tallon/Vallon Zek Ruleset,4 = Sullon Zek Ruleset,6 = Discord Ruleset,anything above 6 is the Discord Ruleset without the no-drop restrictions removed. TODO: Edit IsAttackAllowed in Zone to accomodate for these rules.'),(10,'World:ExpansionSettings','16383','Sets the expansion settings for the server,This is sent on login to world and affects client expansion settings. Defaults to all expansions enabled up to TSS.'),(10,'World:SoFStartZoneID','-1','Sets the Starting Zone for SoF Clients separate from Titanium Clients (-1 is disabled)'),(10,'World:MinGMAntiHackStatus','1','Minimum GM status to check against AntiHack list'),(10,'World:GMAccountIPList','false','Check ip list against GM Accounts,AntiHack GM Accounts.'),(10,'World:ExemptAccountLimitStatus','-1','Min status required to be exempt from multi-session per account limiting (-1 is disabled)'),(10,'World:AccountSessionLimit','-1','Max number of characters allowed on at once from a single account (-1 is disabled)'),(10,'World:DeleteStaleCorpeBackups','true','Deletes stale corpse backups older than 2 weeks.'),(10,'World:ClearTempMerchantlist','true','Clears temp merchant items when world boots.'),(10,'World:MaxClientsSetByStatus','false','If true,IP Limiting will be set to the status on the account as long as the status is > MaxClientsPerIP'),(10,'World:AddMaxClientsStatus','-1','Accounts with status >= this rule will be allowed to use the amount of accounts defined in the AddMaxClientsPerIP. Default value: -1 (feature disabled)'),(10,'World:AddMaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < ExemptMaxClientsStatus. Default value: -1 (feature disabled)'),(10,'World:ExemptMaxClientsStatus','-1','Exempt accounts from the MaxClientsPerIP and AddMaxClientsStatus rules,if their status is >= this value. Default value: -1 (feature disabled'),(10,'World:MaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < AddMaxClientsStatus. Default value: -1 (feature disabled)'),(10,'World:MinOfflineTimeToReturnHome','21600','21600 seconds is 6 Hours'),(10,'World:TutorialZoneID','189',''),(10,'World:GuildBankZoneID','345',''),(10,'World:EnableReturnHomeButton','true',''),(10,'World:MaxLevelForTutorial','10',''),(10,'World:EnableTutorialButton','true',''),(10,'World:ClientKeepaliveTimeoutMS','65000',''),(10,'World:UseBannedIPsTable','false','Toggle whether or not to check incoming client connections against the Banned_IPs table. Set this value to false to disable this feature.'),(10,'World:ZoneAutobootTimeoutMS','60000',''),(10,'GM:MinStatusToZoneAnywhere','250',''),(10,'Pets:UnTargetableSwarmPet','false',''),(10,'Pets:AttackCommandRange','150',''),(10,'Skills:MaxTrainSpecializations','50','Max level a GM trainer will train casting specializations'),(10,'Skills:UseLimitTradeskillSearchSkillDiff','true',''),(10,'Skills:MaxTradeskillSearchSkillDiff','50',''),(10,'Skills:MaxTrainTradeskills','21',''),(10,'Guild:PlayerCreationRequiredTime','0','Required Time Entitled On Account (in Minutes,\"); to create the guild.'),(10,'Guild:PlayerCreationRequiredLevel','0','Required Level of the player attempting to create the guild.'),(10,'Guild:PlayerCreationRequiredStatus','0','Required admin status.'),(10,'Guild:PlayerCreationLimit','1',' Only allow use of the UF+ window if the account has < than this number of guild leaders on it'),(10,'Mercs:ScaleRate','100',''),(10,'Guild:MaxMembers','2048',''),(10,'Guild:PlayerCreationAllowed','false','Allow players to create a guild using the window in Underfoot+'),(10,'Mercs:ResurrectRadius','50','Determines the distance from which a healer merc will attempt to resurrect a group members corpse'),(10,'Mercs:AggroRadiusPuller','25','Determines the distance from which a merc will aggro group members target,if they have the group role of puller (also used to determine the distance at which a healer merc will begin healing a group member,if they have the group role of puller'),(10,'Mercs:ChargeMercUpkeepCost','false',''),(10,'Mercs:AggroRadius','100',' Determines the distance from which a merc will aggro group members target(also used to determine the distance at which a healer merc will begin healing a group member'),(10,'Mercs:AllowMercs','false',''),(10,'Mercs:ChargeMercPurchaseCost','false',''),(10,'Mercs:SuspendIntervalS','10',''),(10,'Mercs:UpkeepIntervalS','180',''),(10,'Mercs:UpkeepIntervalMS','180000',''),(10,'Mercs:SuspendIntervalMS','10000',''),(10,'Character:BaseRunSpeedCap','158','Base Run Speed Cap,on live its 158% which will give you a runspeed of 1.580 hard capped to 225.'),(10,'Character:BaseInstrumentSoftCap','36','Softcap for instrument mods,36 commonly referred to as 3.6 as well.'),(10,'Character:FoodLossPerUpdate','35','How much food/water you lose per stamina update'),(10,'Character:KeepLevelOverMax','false','Dont delevel a character that has somehow gone over the level cap'),(10,'Character:EnableXTargetting','true','Enable Extended Targetting Window,for users with UF and later clients.'),(10,'Character:EnableDiscoveredItems','true','If enabled,it enables EVENT_DISCOVER_ITEM and also saves character names and timestamps for the first time an item is discovered.'),(10,'Character:MaintainIntoxicationAcrossZones','true','If true,alcohol effects are maintained across zoning and logging out/in.'),(10,'Character:StatCap','0',''),(10,'Character:CheckCursorEmptyWhenLooting','true','If true,a player cannot loot a corpse (player or NPC) with an item on their cursor'),(10,'Character:SkillCapMaxLevel','75','Sets the Max Level used for Skill Caps (from skill_caps table) -1 makes it use MaxLevel rule value. It is set to 75 because PEQ only has skillcaps up to that level,and grabbing the players skill past 75 will return 0,breaking all skills past that level. This helps servers with obsurd level caps (75+ level cap) function without any modifications.'),(10,'Character:MinStatusForNoDropExemptions','80','This allows status x and higher to trade no drop items.'),(10,'Character:ItemCastsUseFocus','false','If true, this allows item clickies to use focuses that have limited max levels on them'),(10,'Character:UseNewStatsWindow','true',' New stats window shows everything'),(10,'Character:RespawnFromHoverTimer','300','Respawn Window countdown timer in SECONDS'),(10,'Character:RespawnFromHover','false',' Use Respawn window or not.'),(10,'Character:UseRaceClassExpBonuses','true','Setting this to true will enable Class and Racial experience rate bonuses'),(10,'Character:SoDClientUseSoDHPManaEnd','false','Setting this to true will allow SoD clients to use the SoD HP/Mana/End formulas and previous clients will use the old formulas'),(10,'Character:BaseHPRegenBonusRaces','4352','a bitmask of race(s) that receive the regen bonus. Iksar (4096) & Troll (256) = 4352. see common/races.h for the bitmask values'),(10,'Character:MaxCharmDurationForPlayerCharacter','15',''),(10,'Character:MaxFearDurationForPlayerCharacter','4','4 tics,each tic calculates every 6 seconds.'),(10,'Character:KillsPerRaidLeadershipAA','250','Number of dark blues or above per Raid Leadership AA'),(10,'Character:KillsPerGroupLeadershipAA','250','Number of dark blues or above per Group Leadership AA'),(10,'Character:RestRegenEndurance','false','Whether rest regen will work for endurance or not.'),(10,'Character:RestRegenTimeToActivate','30','Time in seconds for rest state regen to kick in.'),(10,'Character:BindAnywhere','false',''),(10,'Character:RestRegenPercent','0','Set to >0 to enable rest state bonus HP and mana regen.'),(10,'Character:SharedBankPlat','false','off by default to prevent duping for now'),(10,'Character:SkillUpModifier','100','skill ups are at 100%'),(10,'Character:HasteCap','100','Haste cap for non-v3(overhaste) haste.'),(10,'Character:ItemEnduranceRegenCap','15',''),(10,'Character:ItemExtraDmgCap','150','Cap for bonuses to melee skills like Bash,Frenzy,etc'),(10,'Character:ItemClairvoyanceCap','250',''),(10,'Character:ItemDSMitigationCap','50',''),(10,'Character:ItemATKCap','250',''),(10,'Character:ItemHealAmtCap','250',''),(10,'Character:ItemSpellDmgCap','250',''),(10,'Character:ItemStunResistCap','35',''),(10,'Character:ItemStrikethroughCap','35',''),(10,'Character:ItemDoTShieldingCap','35',''),(10,'Character:ItemSpellShieldingCap','35',''),(10,'Character:ItemShieldingCap','35',''),(10,'Character:ItemAvoidanceCap','100',''),(10,'Character:ItemCombatEffectsCap','100',''),(10,'Character:ItemDamageShieldCap','30',''),(10,'Character:ItemAccuracyCap','150',''),(10,'Character:ItemHealthRegenCap','35',''),(10,'Character:FeignKillsPet','false',''),(10,'Character:ItemManaRegenCap','15',''),(10,'Character:HealOnLevel','false',''),(10,'Character:EnduranceRegenMultiplier','100',''),(10,'Character:ConsumptionMultiplier','100','items hunger restored = this value * items food level,100 = normal,50 = people eat 2x as fast,200 = people eat 2x as slow'),(10,'Character:HPRegenMultiplier','100',''),(10,'Character:ManaRegenMultiplier','100',''),(10,'Character:AutosaveIntervalS','300','0=disabled'),(10,'Character:RedModifier','150',''),(10,'Character:YellowModifier','125',''),(10,'Character:WhiteModifier','100',''),(10,'Character:BlueModifier','90',''),(10,'Character:LightBlueModifier','40',''),(10,'Character:RaidExpMultiplier','0.2',''),(10,'Character:UseXPConScaling','true',''),(10,'Character:GroupExpMultiplier','0.5',''),(10,'Character:AAExpMultiplier','0.5',''),(10,'Character:ExpMultiplier','0.5',''),(10,'Character:MaxDraggedCorpses','2',''),(10,'Character:DragCorpseDistance','400','If the corpse is <= this distance from the player,it wont move'),(10,'Character:LeaveCorpses','true',''),(10,'Character:LeaveNakedCorpses','false',''),(10,'Character:CorpseResTimeMS','10800000','time before cant res corpse(3 hours)'),(10,'Character:CorpseDecayTimeMS','10800000',''),(10,'Character:UseDeathExpLossMult','false','Adjust to use the above multiplier or to use code default.'),(10,'Character:DeathItemLossLevel','10',''),(10,'Character:DeathExpLossMultiplier','3','Adjust how much exp is lost'),(10,'Character:DeathExpLossMaxLevel','255','Any level greater than this will no longer lose exp on death'),(10,'Character:DeathExpLossLevel','10','Any level greater than this will lose exp on death'),(10,'Character:MaxExpLevel','0','Sets the Max Level attainable via Experience'),(10,'Character:PerCharacterQglobalMaxLevel','false','This will check for qglobal CharMaxLevel character qglobal (Type 5),if player tries to level beyond that point,it will not go beyond that level'),(2,'Zone:LevelBasedEXPMods','true',''),(1,'Zone:LevelBasedEXPMods','true',''),(1,'Mercs:ResurrectRadius','50','Determines the distance from which a healer merc will attempt to resurrect a corpse'),(1,'Mercs:ChargeMercPurchaseCost','false','Turns Mercenary purchase costs on or off.'),(1,'Mercs:ChargeMercUpkeepCost','false','Turns Mercenary upkeep costs on or off.'),(1,'Spells:BuffLevelRestrictions','true',''),(2,'Spells:BuffLevelRestrictions','true',''),(10,'Character:MaxLevel','65',''),(4,'NPC:MinorNPCCorpseDecayTimeMS','1800000','level<55'),(4,'AA:ExpPerPoint','23976503','Amount of exp per AA. Is the same as the amount of exp to go from level 51 to level 52.'),(4,'AA:MaxEffectSlots','7','the highest slot # used in the aa_effects table. have to use MAX_AA_EFFECT_SLOTS for now'),(4,'AA:Stacking','true','Enable stacking of AA within the same series on all clients'),(4,'Adventure:DistanceForRescueAccept','10000.0',''),(4,'Adventure:DistanceForRescueComplete','2500.0',''),(4,'Adventure:ItemIDToEnablePorts','41000',''),(4,'Adventure:MaxLevelRange','9',''),(4,'Adventure:MaxNumberForGroup','6',''),(4,'Adventure:MaxNumberForRaid','36',''),(4,'Adventure:MinNumberForGroup','2',''),(4,'Adventure:MinNumberForRaid','18',''),(4,'Adventure:NumberKillsForBossSpawn','40',''),(4,'Aggro:CriticallyWoundedAggroMod','100','notation'),(4,'Aggro:CurrentTargetAggroMod','0','0 will prefer our current target to any other, > 0 makes it harder for our npcs to switch targets.'),(4,'Aggro:MeleeRangeAggroMod','20','notation'),(4,'Aggro:PetSpellAggroMod','10','notation'),(4,'Aggro:SittingAggroMod','35','notation'),(4,'Aggro:SmartAggroList','true','notation'),(4,'Aggro:SongAggroMod','33','notation'),(4,'Aggro:SpellAggroMod','100','notation'),(4,'Bazaar:AuditTrail','true','notation'),(4,'Bazaar:EnableWarpToTrader','true','notation'),(4,'Bazaar:MaxBarterSearchResults','200','The max results returned in the /barter search'),(4,'Bazaar:MaxSearchResults','200','notation'),(4,'Bots:BotAAExpansion','8','The expansion through which bots will obtain AAs'),(4,'Channels:DeleteTimer','1440','Empty password protected channels will be deleted after this many minutes'),(4,'Channels:RequiredStatusAdmin','251','Required status to administer chat channels'),(4,'Channels:RequiredStatusListAll','251','Required status to list all chat channels'),(4,'Character:AAExpMultiplier','0.65','notation'),(4,'Character:AutosaveIntervalS','300','0=disabled'),(4,'Character:BindAnywhere','false','notation'),(4,'Character:BlueModifier','90',''),(4,'Character:CheckCursorEmptyWhenLooting','true','If true, a player cannot loot a corpse (player or NPC) with an item on their cursor'),(4,'Character:ConsumptionMultiplier','100',''),(4,'Character:CorpseDecayTimeMS','43200000','notation'),(4,'Character:CorpseResTimeMS','10800000','Time to res a corpse(ms)'),(4,'Character:DeathExpLossLevel','10','notation'),(4,'Character:DeathExpLossMaxLevel','255','Any level greater than this will no longer lose exp on death'),(4,'Character:DeathExpLossMultiplier','3','Adjust how much exp is lost'),(4,'Character:DeathItemLossLevel','10','notation'),(4,'Character:DragCorpseDistance','400.000000','If a player is using /corpsedrag and moving, the corpse will not move until the player exceeds this distance (NoRootNoZ)'),(4,'Character:EnableDiscoveredItems','false','If enabled, it enables EVENT_DISCOVER_ITEM and also saves character names and timestamps'),(4,'Character:EnableXTargetting','true',''),(4,'Character:EnduranceRegenMultiplier','100','notation'),(4,'Character:ExpMultiplier','0.65','notation'),(4,'Character:FeignKillsPet','false','notation'),(4,'Character:GroupExpMultiplier','0.65','notation'),(4,'Character:HasteCap','100','Haste cap for item haste + spell haste(not including overhaste)'),(4,'Character:HealOnLevel','false','notation'),(4,'Character:HPRegenMultiplier','100','notation'),(4,'Character:ItemAccuracyCap','150','notation'),(4,'Character:ItemAvoidanceCap','100','notation'),(4,'Character:ItemCastsUseFocus','false','If true, this allows item clickies to use focuses that have limited max levels on them'),(4,'Character:ItemClairvoyanceCap','250','Clairvoyance returns mana after a cast under certain circumstances'),(4,'Character:ItemCombatEffectsCap','100','notation'),(4,'Character:ItemDamageShieldCap','30','notation'),(4,'Character:ItemDoTShieldingCap','35','notation'),(4,'Character:ItemDSMitigationCap','50','Mitigates the effect of a damage shield'),(4,'Character:ItemEnduranceRegenCap','15','Endurance cap from items'),(4,'Character:ItemExtraDmgCap','150','eg +bash, +frenzy dmg, etc'),(4,'Character:ItemHealAmtCap','250','Heal Amt adds to heal spells based on their cast & recast time'),(4,'Character:ItemHealthRegenCap','15','notation'),(4,'Character:ItemManaRegenCap','15','notation'),(4,'Character:ItemShieldingCap','35','notation'),(4,'Character:ItemSpellDmgCap','250','Spell Dmg adds to DD spells based on their cast & recast time'),(4,'Character:ItemSpellShieldingCap','35','notation'),(4,'Character:ItemStrikethroughCap','35','notation'),(4,'Character:ItemStunResistCap','35','notation'),(4,'Character:KillsPerGroupLeadershipAA','250',''),(4,'Character:KillsPerRaidLeadershipAA','250',''),(4,'Character:LeaveCorpses','true','notation'),(4,'Character:LeaveNakedCorpses','true','notation'),(4,'Character:LightBlueModifier','40',''),(4,'Character:MaintainIntoxicationAcrossZones','true','If true, alcohol effects are maintained across zoning and logging out/in.'),(4,'Character:ManaRegenMultiplier','100','notation'),(4,'Character:MaxCharmDurationForPlayerCharacter','15','15 tics, each tic calculates every 6 seconds.'),(4,'Character:MaxDraggedCorpses','2','Maximum number of corpses that a player can /corpsedrag at once'),(4,'Character:MaxExpLevel','65','Sets the Max Level attainable via Experience'),(4,'Character:MaxFearDurationForPlayerCharacter','4','4 tics, each tic calculates every 6 seconds.'),(4,'Character:MaxLevel','65','notation'),(4,'Character:MinStatusForNoDropExemptions','80','Enables bypassing of no-drop flags if status is set to this value and FVNoDropFlag is set to 2.'),(4,'Character:PerCharacterQglobalMaxLevel','false','Allows Character Max Level based on qglobal \"CharMaxLevel'),(4,'Character:RaidExpMultiplier','0.2','notation'),(4,'Character:RedModifier','150',''),(4,'Character:RespawnFromHover','false','Enable Respawn Window for SoF and later clients.'),(4,'Character:RespawnFromHoverTimer','300','Respawn Window Timer in Seconds.'),(4,'Character:RestRegenEndurance','false','Whether rest regen will affect endurance or not'),(4,'Character:RestRegenPercent','0','Set to >0 to enable rest state bonus HP and mana regen.'),(4,'Character:RestRegenTimeToActivate','30000','Time in seconds for rest state regen to kick in.'),(4,'Character:SharedBankPlat','true','off by default to prevent duping for now'),(4,'Character:SkillCapMaxLevel','-1','Sets the Max Level used for Skill Caps (from skill_caps table).  Default of -1 makes it use MaxLevel rule value.'),(4,'Character:SkillUpModifier','100','skill ups are at 100%'),(4,'Character:SoDClientUseSoDHPManaEnd','true','Setting this to true will allow SoD clients to use the SoD HP/Mana/End formulas and previous clients will use the old formulas'),(4,'Character:StatCap','0','Sets the Max Statistics Cap for PCs. 0 = feature disabled'),(4,'Character:SumCorpseDecayTimeMS','43200000',''),(4,'Character:UseDeathExpLossMult','false','Adjust to use the above multiplier or to use code default.'),(4,'Character:UseNewStatsWindow','true','New stats window shows so much it got the TSA seal of approval'),(4,'Character:UseRaceClassExpBonuses','true','Setting this to true will enable Class and Racial experience rate bonuses'),(4,'Character:UseXPConScaling','true',''),(4,'Character:WhiteModifier','100',''),(4,'Character:YellowModifier','125',''),(4,'Chat:EnableAntiSpam','true','notation'),(4,'Chat:EnableMailKeyIPVerification','true','notation'),(4,'Chat:EnableVoiceMacros','true','notation'),(4,'Chat:FlowCommandstoPerl_EVENT_SAY','true',''),(4,'Chat:GlobalChatLevelLimit','5','level limit you need to of reached to talk in ooc/auction/chat if your karma is too low.'),(4,'Chat:IntervalDurationMS','60000','notation'),(4,'Chat:KarmaGlobalChatLimit','72','amount of karma you need to be able to talk in ooc/auction/chat below the level limit'),(4,'Chat:KarmaUpdateIntervalMS','1200000','notation'),(4,'Chat:MaximumMessagesPerInterval','12','notation'),(4,'Chat:MaxMessagesBeforeKick','20','notation'),(4,'Chat:MinimumMessagesPerInterval','4','notation'),(4,'Chat:MinStatusToBypassAntiSpam','80','notation'),(4,'Chat:ServerWideAuction','true','notation'),(4,'Chat:ServerWideOOC','true','notation'),(4,'Chracter:DeathExpLossMaxLevel','255','Any level greater than this will no longer lose exp on death'),(4,'Combat:AdjustProcPerMinute','true','notation'),(4,'Combat:AgiHitFactor','0.01','notation'),(4,'Combat:ArcheryBaseDamageBonus','1','Modifier to Base Archery Damage .5 = 50%, 1 = 100%, 2 = 200%'),(4,'Combat:ArcheryBonusRequiresStationary','true','does the 2x archery bonus chance require a stationary npc'),(4,'Combat:ArcheryHitPenalty','0.45','Archery has a hit penalty to try to help balance it with the plethora of long term +hit modifiers for it'),(4,'Combat:ArcheryNPCMultiplier','1.0','Multiplied by the min and max hit to determine npcs ranged dmg'),(4,'Combat:AssistNoTargetSelf','false','When assisting a target without a target: true = target self, false = leave target as was before assist (this is the behavior on live)'),(4,'Combat:AvgDefProcsPerMinute','2','Default 2. Determines defensive procs per minute.'),(4,'Combat:AvgProcsPerMinute','2.0','notation'),(4,'Combat:BaseHitChance','69','notation'),(4,'Combat:BaseProcChance','0.035','notation'),(4,'Combat:BerserkBaseCritChance','6',''),(4,'Combat:ClientBaseCritChance','0',''),(4,'Combat:DefProcPerMinAgiContrib','0.075','Default 25. Determines how much agility effects proc rate.'),(4,'Combat:DragonPunchBonus','20','% Modifier that this skill gets to str and skill bonuses'),(4,'Combat:EagleStrikeBonus','15','% Modifier that this skill gets to str and skill bonuses'),(4,'Combat:EnableFearPathing','true',''),(4,'Combat:FleeHPRatio','21',''),(4,'Combat:FleeIfNotAlone','false',''),(4,'Combat:FleeSnareHPRatio','21','HP at which snare will halt movement of a fleeing NPC.'),(4,'Combat:FlyingKickBonus','25','% Modifier that this skill gets to str and skill bonuses'),(4,'Combat:FrenzyBonus','0','Modify Frenzy skill damage by percent,'),(4,'Combat:HitBonusPerLevel','1.2',''),(4,'Combat:HitFalloffMajor','50.0',''),(4,'Combat:HitFalloffMinor','5.0','hit will fall off up to 5% over the initial level range'),(4,'Combat:HitFalloffModerate','7.0','hit will fall off up to 7% over the three levels after the initial level range'),(4,'Combat:MaxFlurryHits','2','max number of extra hits from flurry'),(4,'Combat:MaxRampageTargets','3','max number of people hit with rampage'),(4,'Combat:MeleeBaseCritChance','0','The base crit chance for non warriors:NOTE: This will apply to NPCs as well'),(4,'Combat:MonkDamageTableBonus','10','% bonus monks get to their damage table calcs'),(4,'Combat:NPCBashKickLevel','6',''),(4,'Combat:NPCBashKickStunChance','15','Percent chance that a bash/kick will stun'),(4,'Combat:NPCBonusHitChance','26.0','notation'),(4,'Combat:NPCFlurryChance','20','(Default=20) Chance for NPC to flurry if special attack F '),(4,'Combat:PetAttackMagicLevel','30',''),(4,'Combat:ProcDexDivideBy','11000','notation'),(4,'Combat:ProcPerMinDexContrib','0.075','notation'),(4,'Combat:RoundKickBonus','5','% Modifier that this skill gets to str and skill bonuses'),(4,'Combat:SpecialAttackACBonus','15','(Default=15) Percent amount of damage per AC gained for certain special attacks (damage = AC*SpecialAttackACBonus/100).'),(4,'Combat:TauntSkillFalloff','0.33','(Default=0.33) For every taunt skill point thats not maxed you lose this % chance to taunt.'),(4,'Combat:TigerClawBonus','10','% Modifier that this skill gets to str and skill bonuses'),(4,'Combat:UseIntervalAC','true',''),(4,'Combat:WarBerBaseCritChance','3','The base crit chance for warriors and berserkers:only applies to clients'),(4,'Combat:WarriorThreatBonus','0',''),(4,'Combat:WeaponSkillFalloff','0.33',''),(4,'Console:SessionTimeOut','600000','This sets the default timeout time for Telnet sessions (MS)'),(4,'EventLog:RecordBuyFromMerchant','false','Record purchases by a player from an NPC merchant in eventlog table'),(4,'EventLog:RecordSellToMerchant','false','Record sales from a player to an NPC merchant in eventlog table'),(4,'GM:MinStatusToZoneAnywhere','250','This setting overrides the minstatus setting in the zones table if set'),(4,'Guild:MaxMembers','2048','Max number of members allowed in a single guild'),(4,'Guild:PlayerCreationAllowed','true','Allow players with Underfoot+ to create a guild via new UI window.'),(4,'Guild:PlayerCreationLimit','1','Allow players to create a guild using the window in Underfoot+'),(4,'Guild:PlayerCreationRequiredLevel','0','Required level to use the UF+ window to create a new guild.'),(4,'Guild:PlayerCreationRequiredStatus','0','Required admin status to use UF+ window to create a new guild.'),(4,'Guild:PlayerCreationRequiredTime','0','Required Time Entitled on Account to be able to use UF+ window to create a new guild.'),(4,'Mail:EnableMailSystem','true','If false:client wont bring up the Mail window.'),(4,'Mail:ExpireRead','31536000','1 Year. Set to -1 for never'),(4,'Mail:ExpireTrash','0','Time in seconds. 0 will delete all messages in the trash when the mailserver starts'),(4,'Mail:ExpireUnread','31536000','1 Year. Set to -1 for never'),(4,'Map:FindBestZHeightAdjust','1',''),(4,'Map:FixPathingZAtWaypoints','true',''),(4,'Map:FixPathingZMaxDeltaLoading','20',''),(4,'Map:FixPathingZMaxDeltaMoving','20',''),(4,'Map:FixPathingZMaxDeltaSendTo','20',''),(4,'Map:FixPathingZMaxDeltaWaypoint','20',''),(4,'Map:FixPathingZOnSendTo','false',''),(4,'Map:FixPathingZWhenLoading','true',''),(4,'Map:FixPathingZWhenMoving','true',''),(4,'Map:UseClosestZ','true',''),(4,'Merchant:BuyCostMod','0.95','Modifier for NPC buy price.'),(4,'Merchant:ChaBonusMod','3.45','Determines CHA cap:from 104 CHA. 3.45 is 132 CHA at apprehensive. 0.34 is 400 CHA at apprehensive.'),(4,'Merchant:ChaPenaltyMod','1.52','Determines CHA bottom:up to 102 CHA. 1.52 is 37 CHA at apprehensive. 0.98 is 0 CHA at apprehensive.'),(4,'Merchant:PriceBonusPct','4','Determines maximum price bonus from having good faction/CHA. Value is a percent.'),(4,'Merchant:PricePenaltyPct','4','Determines maximum price penalty from having bad faction/CHA. Value is a percent.'),(4,'Merchant:SellCostMod','1.05','Modifier for NPC sell price.'),(4,'Merchant:UsePriceMod','true','Use faction/charisma price modifiers.'),(4,'Mercs:AggroRadius','100','Determines the distance from which a merc will aggro target(also used to determine the distance at which a healer merc will begin healing a group member)'),(4,'Mercs:AggroRadiusPuller','25','Determines the distance from which a merc will aggro target, if they have the group role of puller (also used to determine the distance at which a healer merc will begin healing a group member, if they have the group role of puller)'),(4,'Mercs:AllowMercs','false','Turns mercs on for the server - will not load merc data if set to false.'),(4,'Mercs:ScaleRate','100','Allows scaling of merc stats vs livelike values.'),(4,'Mercs:SuspendIntervalMS','10000','Time interval for suspend command in milliseconds.'),(4,'Mercs:SuspendIntervalS','10','Time interval for suspend command in seconds.'),(4,'Mercs:UpkeepIntervalMS','180000','Time interval for merc upkeep in milliseconds.'),(4,'Mercs:UpkeepIntervalS','180','Time interval for merc upkeep in seconds.'),(4,'NPC:BuffFriends','false','notation'),(4,'NPC:CorpseUnlockTimer','150000','notation'),(4,'NPC:EmptyNPCCorpseDecayTimeMS','0','notation'),(4,'NPC:EnableNPCQuestJournal','true','notation'),(4,'NPC:LastFightingDelayMovingMax','20000','Maximum time (in ms) before mob goes home after all aggro loss'),(4,'NPC:LastFightingDelayMovingMin','5000','Minimum time (in ms) before mob goes home after all aggro loss'),(4,'NPC:LiveLikeEnrage','false','If enabled, will cause all non-player pets to lose the ability to enrage.'),(4,'NPC:MajorNPCCorpseDecayTimeMS','1800000','level>=55'),(4,'NPC:OOCRegen','1','notation'),(4,'NPC:ReturnNonQuestNoDropItems','true','Return NO DROP items on NPCs that do not have an EVENT_ITEM sub in their script'),(4,'NPC:SayPauseTimeInSec','10','notation'),(4,'NPC:SmartLastFightingDelayMoving','true','When true, mobs that started going home previously will do so again immediately if still on FD hate list'),(4,'NPC:StartEnrageValue','9','% HP value that mobs will begin to enrage.'),(4,'NPC:UseItemBonusesForNonPets','true','notation'),(4,'Pathing:Aggro','true',''),(4,'Pathing:AggroReturnToGrid','true',''),(4,'Pathing:CandidateNodeRangeXY','400.000000',''),(4,'Pathing:CandidateNodeRangeZ','50.0000000',''),(4,'Pathing:CullNodesFromEnd','1',''),(4,'Pathing:CullNodesFromStart','1',''),(4,'Pathing:Fear','true',''),(4,'Pathing:Guard','true',''),(4,'Pathing:LOSCheckFrequency','1000',''),(4,'Pathing:MaxNodesLeftForLOSCheck','4',''),(4,'Pathing:MinDistanceForLOSCheckLong','1000000.00',''),(4,'Pathing:MinDistanceForLOSCheckShort','40000.0000',''),(4,'Pathing:MinNodesTraversedForLOSCheck','3',''),(4,'Pathing:RouteUpdateFrequencyLong','5000',''),(4,'Pathing:RouteUpdateFrequencyNodeCount','5',''),(4,'Pathing:RouteUpdateFrequencyShort','1000',''),(4,'Pathing:ZDiffThreshold','10.0000000',''),(4,'Pets:AttackCommandRange','200','Range at which a pet will respond to attack commands'),(4,'Pets:UnTargetableSwarmPet','false','Set true to allow swarm pets to not be targeted by clients.'),(4,'QueryServ:MerchantLogTransactions','false',''),(4,'QueryServ:PlayerChatLogging','false',''),(4,'QueryServ:PlayerLogDeletes','false',''),(4,'QueryServ:PlayerLogHandins','false',''),(4,'QueryServ:PlayerLogMoneyTrades','false',''),(4,'QueryServ:PlayerLogMoves','false',''),(4,'QueryServ:PlayerLogNPCKills','false',''),(4,'QueryServ:PlayerLogPCCoordinates','false',''),(4,'QueryServ:PlayerLogTrades','false',''),(4,'Skills:MaxTradeskillSearchSkillDiff','50','The maximum difference in skill between the trivial of an item and the skill of the player if the trivial is higher than the skill. Recipes that have not been learnt or made at least once via the Experiment mode will be removed from searches based on this criteria.'),(4,'Skills:MaxTrainSpecializations','50','Max level a GM trainer will train casting specializations'),(4,'Skills:MaxTrainTradeskills','21','Highest skill level that tradeskills can be trained to from GM Trainers'),(4,'Skills:UseLimitTradeskillSearchSkillDiff','true','Enables the limit for the maximum difference between trivial and skill for recipe searches and favorites.'),(4,'Spells:AdditiveBonusValues','false','Allow certain bonuses to be calculated by adding together the value from each item, instead of taking the highest value. (ie Add together all Cleave Effects)'),(4,'Spells:AutoResistDiff','15','notation'),(4,'Spells:AvgSpellProcsPerMinute','6.0','Default = 6.0 Determines proc rate of spells applied from sympathetic focus effect'),(4,'Spells:BaseCritChance','0','base % chance that everyone has to crit a spell'),(4,'Spells:BaseCritRatio','100','base % bonus to damage on a successful spell crit. 100 = 2x damage'),(4,'Spells:BuffLevelRestrictions','true',''),(4,'Spells:CharismaEffectiveness','10','Default 10 CHA = -1 resist mod. Deterimes how much resist modification charisma applies to charm/pacify checks.'),(4,'Spells:CharmBreakCheckChance','25','Default 25. Determines percent chance for a charm break check to occur each buff tick.'),(4,'Spells:DeathSaveCharismaMod','3','Determines how much charisma effects chance of death save firing.(CHA*value/10)'),(4,'Spells:DivineInterventionHeal','8000','Divine intervention heal amount.'),(4,'Spells:EnableBlockedBuffs','true',''),(4,'Spells:EnableSpellGlobals','false','If true, spells check the spell_globals table against quest globals before allowing spells to scribe via quest::scribespell'),(4,'Spells:LiveLikeFocusEffects','true','Makes certain healing, dmg and mana reduction focuses random like live'),(4,'Spells:MaxBuffSlotsNPC','25',''),(4,'Spells:MaxCastTimeReduction','50','Max percent your spell cast time can be reduced by spell haste.'),(4,'Spells:MaxDiscSlotsNPC','1',''),(4,'Spells:MaxSongSlotsNPC','10',''),(4,'Spells:MaxTotalSlotsNPC','36',''),(4,'Spells:PartialHitChance','0.7','The chance when a spell is resisted that it will partial hit.'),(4,'Spells:PartialHitChanceFear','0.25','The chance when a fear spell is resisted that it will partial hit.'),(4,'Spells:ReflectType','1','0 = disabled, 1 = single target player spells only, 2 = all player spells, 3 = all single target spells, 4 = all spells'),(4,'Spells:ResistChance','2.0','chance to resist given no resists and same level'),(4,'Spells:ResistFalloff','67','Default = 67 Max that level that will adjust our resist chance based on level modifiers'),(4,'Spells:ResistMod','0.40','multiplier:chance to resist = this * ResistAmount'),(4,'Spells:ResistPerLevelDiff','85','8.5 resist per level difference.'),(4,'Spells:RootBreakFromSpells','55','Chance for root to break when cast on.'),(4,'Spells:SacrificeItemID','9963','Item ID of the item Sacrifice will return. Defaults to an Essence Emerald.'),(4,'Spells:SacrificeMaxLevel','69','Last level Sacrifice will work on'),(4,'Spells:SacrificeMinLevel','46','First level Sacrifice will work on'),(4,'Spells:TranslocateTimeLimit','0','If not zero:time in seconds to accept a Translocate.'),(4,'Spells:VirusSpreadDistance','30','The distance a viral spell will jump to its next victim'),(4,'Spells:WizCritChance','5',''),(4,'Spells:WizCritLevel','12','level wizards first get spell crits'),(4,'Spells:WizCritRatio','0',''),(4,'TaskSystem:EnableTaskProximity','true','notation'),(4,'TaskSystem:EnableTaskSystem','true','Globally enable or disable the Task system'),(4,'TaskSystem:KeepOneRecordPerCompletedTask','true','notation'),(4,'TaskSystem:PeriodicCheckTimer','5',''),(4,'TaskSystem:RecordCompletedOptionalActivities','true','notation'),(4,'TaskSystem:RecordCompletedTasks','true','notation'),(4,'Watermap:CheckForWaterAtWaypoints','true',''),(4,'Watermap:CheckForWaterOnSendTo','false','Checks if a mob has moved into/out of water on SendTo'),(4,'Watermap:CheckForWaterWhenFishing','true','Only lets a player fish near water (if a water map exists for the zone)'),(4,'Watermap:CheckForWaterWhenMoving','true',''),(4,'Watermap:CheckWaypointsInWaterWhenLoading','true',''),(4,'Watermap:FishingLineLength','40','If water is more than this far below the player:it is considered too far to fish'),(4,'Watermap:FishingRodLength','30','How far in front of player water must be for fishing to work'),(4,'World:AccountSessionLimit','1','Max number of characters allowed on at once from a single account (-1 is disabled)'),(4,'World:AddMaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < ExemptMaxClientsStatus.  Default value: -1 (feature disabled)'),(4,'World:AddMaxClientsStatus','-1','Accounts with status >= this rule will be allowed to use the amount of accounts defined in the AddMaxClientsPerIP.  Default value: -1 (feature disabled)'),(4,'World:ClearTempMerchantlist','false','cavedude: Clears temp merchant items when world boots.'),(4,'World:ClientKeepaliveTimeoutMS','95000','notation'),(4,'World:DeleteStaleCorpeBackups','true','Deletes stale corpse backups older than 2 weeks.'),(4,'World:EnableReturnHomeButton','true','notation'),(4,'World:EnableTutorialButton','true','notation'),(4,'World:ExemptAccountLimitStatus','200','Min status required to be exempt from multi-session per account limiting (-1 is disabled)'),(4,'World:ExemptMaxClientsStatus','-1','Exempt accounts from the MaxClientsPerIP and AddMaxClientsStatus rules:if their status is >= this value.  Default value: -1 (feature disabled)'),(4,'World:ExpansionSettings','16383','Expansion settings. Affects client features related to expansions.'),(4,'World:FVNoDropFlag','0','Sets the FV ruleset to on or off. Enable with rule 2 for GM-trading only. Keep in mind this disables OOC chatter for GMs only if you choose that option.'),(4,'World:GMAccountIPList','true','Check ip list against GM Accounts:AntiHack GM Accounts.'),(4,'World:GuildBankZoneID','345','ID of zone the Guild Bank works in. Default 345, guildhall'),(4,'World:IPLimitDisconnectAll','false','Disconnect all current clients by IP if they go over the IP limit.  This should allow people to quickly reconnect in the case of dead sessions waiting to timeout.'),(4,'World:IsGMPetitionWindowEnabled','false',''),(4,'World:MaxClientsPerIP','-1','Maximum number of clients allowed to connect per IP address if account status is < AddMaxClientsStatus.  Default value: -1 (feature disabled)'),(4,'World:MaxClientsSetByStatus','false','If True, IP Limiting will be set to the status on the account as long as the status is > MaxClientsPerIP'),(4,'World:MaxLevelForTutorial','15','notation'),(4,'World:MinGMAntiHackStatus','11','Minimum GM status to check against AntiHack list'),(4,'World:MinOfflineTimeToReturnHome','21600','21600 seconds is 6 Hours'),(4,'World:PVPSettings','0','PVP Settings, affects clients\' attack state and Sony-hardcoded checks for PVP rules.'),(4,'World:TutorialZoneID','189','notation'),(4,'World:UseBannedIPsTable','true','Toggle whether or not to check incoming client connections against the Banned_IPs table. Set this value to false to disable this feature.'),(4,'World:ZoneAutobootTimeoutMS','120000','notation'),(4,'Zone:AutoShutdownDelay','5000',''),(4,'Zone:ClientLinkdeadMS','180000',''),(4,'Zone:EnableMQGateDetector','true',''),(4,'Zone:EnableMQGhostDetector','true',''),(4,'Zone:EnableMQWarpDetector','true',''),(4,'Zone:EnableMQZoneDetector','true',''),(4,'Zone:EnableShadowrest','1',''),(4,'Zone:GraveyardTimeMS','1200000',''),(4,'Zone:HotZoneBonus','0.75','hot zone XP bonus'),(4,'Zone:LevelBasedEXPMods','true',''),(4,'Zone:MarkMQWarpLT','false',''),(4,'Zone:MQGateExemptStatus','80',''),(4,'Zone:MQGhostExemptStatus','80',''),(4,'Zone:MQWarpDetectionDistanceFactor','9.0',''),(4,'Zone:MQWarpExemptStatus','80',''),(4,'Zone:MQZoneExemptStatus','80',''),(4,'Zone:NPCPositonUpdateTicCount','32','ms between intervals of sending a position update to the entire zone.'),(4,'Zone:PEQZoneDebuff1','4454','First debuff casted by #peqzone Default is Cursed Keepers Blight.'),(4,'Zone:PEQZoneDebuff2','2209','Second debuff casted by #peqzone Default is Tendrils of Apathy.'),(4,'Zone:PEQZoneReuseTime','300','Amount of time, in seconds, before you can reuse the #peqzone command'),(4,'Zone:UsePEQZoneDebuffs','false','Will determine if #peqzone will debuff players or not when used.'),(4,'Zone:UsePlayerCorpseBackups','true','Keeps backups of player corpses.'),(1,'Zone:WeatherTimer','600',''),(2,'Zone:WeatherTimer','600',''),(4,'Zone:WeatherTimer','600',''),(10,'Combat:FlyingKickBonus','25','% Modifier that this skill gets to str and skill bonuses'),(10,'Combat:DragonPunchBonus','20','% Modifier that this skill gets to str and skill bonuses'),(10,'Combat:EagleStrikeBonus','15','% Modifier that this skill gets to str and skill bonuses'),(10,'Combat:TigerClawBonus','10','% Modifier that this skill gets to str and skill bonuses'),(10,'Combat:RoundKickBonus','5','% Modifier that this skill gets to str and skill bonuses'),(10,'Combat:FrenzyBonus','0','% Modifier to damage'),(10,'Combat:ProcTargetOnly','true','true = procs will only affect our target,false = procs will affect all of our targets'),(10,'Combat:NPCACFactor','2.25',''),(10,'Combat:ClothACSoftcap','75',''),(10,'Combat:LeatherACSoftcap','100',''),(10,'Combat:MonkACSoftcap','120',''),(10,'Combat:ChainACSoftcap','200',''),(10,'Combat:PlateACSoftcap','300',''),(10,'Combat:AAMitigationACFactor','3.0',''),(10,'Combat:WarriorACSoftcapReturn','0.45',''),(10,'Combat:KnightACSoftcapReturn','0.33',''),(10,'Combat:LowPlateChainACSoftcapReturn','0.23',''),(10,'Combat:LowChainLeatherACSoftcapReturn','0.17',''),(10,'Combat:CasterACSoftcapReturn','0.06',''),(10,'Combat:MiscACSoftcapReturn','0.3',''),(10,'Combat:OldACSoftcapRules','false','use old softcaps'),(10,'Combat:UseOldDamageIntervalRules','false','use old damage formulas for everything'),(10,'Combat:WarACSoftcapReturn','0.3448','new AC returns'),(10,'Combat:ClrRngMnkBrdACSoftcapReturn','0.3030',''),(10,'Combat:PalShdACSoftcapReturn','0.3226',''),(10,'Combat:DruNecWizEncMagACSoftcapReturn','0.2000',''),(10,'Combat:RogShmBstBerACSoftcapReturn','0.2500',''),(10,'Combat:SoftcapFactor','1.88',''),(10,'Combat:ACthac0Factor','0.55',''),(10,'Combat:ACthac20Factor','0.55',''),(10,'Combat:HitCapPre20','40','live has it capped at 40 for whatever dumb reason... this is mainly for custom servers'),(10,'Combat:HitCapPre10','20','live has it capped at 20,see above :p'),(10,'Combat:MinHastedDelay','400','how fast we can get with haste.'),(10,'Combat:AvgDefProcsPerMinute','2.0',''),(10,'Combat:DefProcPerMinAgiContrib','0.075','How much agility contributes to defensive proc rate'),(10,'Combat:SpecialAttackACBonus','15','Percent amount of damage per AC gained for certain special attacks (damage = AC*SpecialAttackACBonus/100)'),(10,'Combat:NPCFlurryChance','20','Chance for NPC to flurry.'),(10,'Combat,TauntOverLevel','1','Allows you to taunt NPCs over warriors level.'),(10,'Combat,TauntSkillFalloff','0.33','For every taunt skill point thats not maxed you lose this % chance to taunt.'),(10,'Combat,EXPFromDmgShield','false','Determine if damage from a damage shield counts for EXP gain.'),(10,'Combat:MonkACBonusWeight','15',''),(10,'Combat:ClientStunLevel','55','This is the level where client kicks and bashes can stun the target'),(10,'Combat:QuiverWRHasteDiv','3','Weight Reduction is divided by this to get haste contribution for quivers'),(10,'Combat:UseArcheryBonusRoll','false','Make the 51+ archery bonus require an actual roll'),(10,'Combat:ArcheryBonusChance','50',''),(10,'Combat:BerserkerFrenzyStart','35',''),(10,'Combat:BerserkerFrenzyEnd','45',''),(10,'NPC:MinorNPCCorpseDecayTimeMS','450000','level<55'),(10,'NPC:MajorNPCCorpseDecayTimeMS','1500000','level>=55'),(10,'NPC:CorpseUnlockTimer','150000',''),(10,'NPC:EmptyNPCCorpseDecayTimeMS','0',''),(10,'NPC:UseItemBonusesForNonPets','true',''),(10,'NPC:SayPauseTimeInSec','5',''),(10,'NPC:OOCRegen','0',''),(10,'NPC:BuffFriends','false',''),(10,'NPC:EnableNPCQuestJournal','false',''),(10,'NPC:LastFightingDelayMovingMin','10000',''),(10,'NPC:LastFightingDelayMovingMax','20000',''),(10,'NPC:SmartLastFightingDelayMoving','true',''),(10,'NPC:ReturnNonQuestNoDropItems','false','Returns NO DROP items on NPCs that dont have an EVENT_TRADE sub in their script'),(10,'NPC:StartEnrageValue','9','% HP that an NPC will begin to enrage'),(10,'NPC:LiveLikeEnrage','false','If set to true then only player controlled pets will enrage'),(10,'Aggro:SmartAggroList','true',''),(10,'Aggro:SittingAggroMod','35','35%'),(10,'Aggro:MeleeRangeAggroMod','10','10%'),(10,'Aggro:CurrentTargetAggroMod','0','0% -- will prefer our current target to any other; makes it harder for our npcs to switch targets.'),(10,'Aggro:CriticallyWoundedAggroMod','100','100%'),(10,'Aggro:SpellAggroMod','100',''),(10,'Aggro:SongAggroMod','33',''),(10,'Aggro:PetSpellAggroMod','10',''),(10,'Aggro:TunnelVisionAggroMod','0.75','people not currently the top hate generate this much hate on a Tunnel Vision mob'),(10,'Aggro:MaxStunProcAggro','400','Set to -1 for no limit. Maxmimum amount of aggro that a stun based proc will add.'),(10,'Aggro:IntAggroThreshold','75','Int <= this will aggro regardless of level difference.'),(10,'TaskSystem:EnableTaskSystem','true','Globally enable or disable the Task system'),(10,'TaskSystem:PeriodicCheckTimer','5','Seconds between checks for failed tasks. Also used by the Touch activity'),(10,'TaskSystem:RecordCompletedTasks','true',''),(10,'TaskSystem:RecordCompletedOptionalActivities','false',''),(10,'TaskSystem:KeepOneRecordPerCompletedTask','true',''),(10,'TaskSystem:EnableTaskProximity','true',''),(10,'Bots:BotManaRegen','2.0','Adjust mana regen for bots,1 is fast and higher numbers slow it down 3 is about the same as players.'),(10,'Bots:BotFinishBuffing','false','Allow for buffs to complete even if the bot caster is out of mana. Only affects buffing out of combat.'),(10,'Bots:CreateBotCount','150','Number of bots that each account can create'),(10,'Bots:SpawnBotCount','71','Number of bots a character can have spawned at one time,You + 71 bots is a 12 group raid'),(10,'Bots:BotQuest','false','Optional quest method to manage bot spawn limits using the quest_globals name bot_spawn_limit,see: /bazaar/Aediles_Thrall.pl'),(10,'Bots:BotGroupBuffing','false','Bots will cast single target buffs as group buffs,default is false for single. Does not make single target buffs work for MGB.'),(10,'Bots:BotSpellQuest','false','Anita Thralls (Anita_Thrall.pl) Bot Spell Scriber quests.'),(10,'Bots:BotAAExpansion','8','Bots get AAs through this expansion'),(10,'Bots:BotGroupXP','false','Determines whether client gets xp for bots outside their group.'),(10,'Bots:BotBardUseOutOfCombatSongs','true','Determines whether bard bots use additional out of combat songs.'),(10,'Chat:ServerWideOOC','true',''),(10,'Chat:ServerWideAuction','true',''),(10,'Chat:EnableVoiceMacros','true',''),(10,'Chat:EnableMailKeyIPVerification','true',''),(10,'Chat:EnableAntiSpam','true',''),(10,'Chat:MinStatusToBypassAntiSpam','100',''),(10,'Chat:MinimumMessagesPerInterval','4',''),(10,'Chat:MaximumMessagesPerInterval','12',''),(10,'Chat:MaxMessagesBeforeKick','20',''),(10,'Chat:IntervalDurationMS','60000',''),(10,'Chat:KarmaUpdateIntervalMS','1200000',''),(10,'Chat:KarmaGlobalChatLimit','72','amount of karma you need to be able to talk in ooc/auction/chat below the level limit'),(10,'Chat:GlobalChatLevelLimit','8','level limit you need to of reached to talk in ooc/auction/chat if your karma is too low.'),(10,'Merchant:UsePriceMod','true','Use faction/charisma price modifiers.'),(10,'Merchant:SellCostMod','1.05','Modifier for NPC sell price.'),(10,'Merchant:BuyCostMod','0.95','Modifier for NPC buy price.'),(10,'Merchant:PriceBonusPct','4','Determines maximum price bonus from having good faction/CHA. Value is a percent.'),(10,'Merchant:PricePenaltyPct','4','Determines maximum price penalty from having bad faction/CHA. Value is a percent.'),(10,'Merchant:ChaBonusMod','3.45','Determines CHA cap,from 104 CHA. 3.45 is 132 CHA at apprehensive. 0.34 is 400 CHA at apprehensive.'),(10,'Merchant:ChaPenaltyMod','1.52','Determines CHA bottom,up to 102 CHA. 1.52 is 37 CHA at apprehensive. 0.98 is 0 CHA at apprehensive.'),(10,'Merchant:EnableAltCurrencySell','true','Enables the ability to resell items to alternate currency merchants'),(10,'Bazaar:AuditTrail','false',''),(10,'Bazaar:MaxSearchResults','50',''),(10,'Bazaar:EnableWarpToTrader','true',''),(10,'Bazaar:MaxBarterSearchResults','200','The max results returned in the /barter search'),(10,'Mail:EnableMailSystem','true','If false,client wont bring up the Mail window.'),(10,'Mail:ExpireTrash','0','Time in seconds. 0 will delete all messages in the trash when the mailserver starts'),(10,'Mail:ExpireRead','31536000','1 Year. Set to -1 for never'),(10,'Mail:ExpireUnread','31536000','1 Year. Set to -1 for never'),(10,'Channels:RequiredStatusAdmin','251','Required status to administer chat channels'),(10,'Channels:RequiredStatusListAll','251','Required status to list all chat channels'),(10,'Channels:DeleteTimer','1440','Empty password protected channels will be deleted after this many minutes'),(10,'EventLog:RecordSellToMerchant','false','Record sales from a player to an NPC merchant in eventlog table'),(10,'EventLog:RecordBuyFromMerchant','false','Record purchases by a player from an NPC merchant in eventlog table'),(10,'Adventure:MinNumberForGroup','2',''),(10,'Adventure:MaxNumberForGroup','6',''),(10,'Adventure:MinNumberForRaid','18',''),(10,'Adventure:MaxNumberForRaid','36',''),(10,'Adventure:MaxLevelRange','9',''),(10,'Adventure:NumberKillsForBossSpawn','45',''),(10,'Adventure:DistanceForRescueAccept','10000.0',''),(10,'Adventure:DistanceForRescueComplete','2500.0',''),(10,'Adventure:ItemIDToEnablePorts','41000','0 to disable,otherwise using a LDoN portal will require the user to have this item.'),(10,'Adventure:LDoNTrapDistanceUse','625',''),(10,'Adventure:LDoNBaseTrapDifficulty','15.0',''),(10,'Adventure:LDoNCriticalFailTrapThreshold','10.0',''),(10,'Adventure:LDoNAdventureExpireTime','1800','30 minutes to expire'),(10,'AA:ExpPerPoint','23976503','Amount of exp per AA. Is the same as the amount of exp to go from level 51 to level 52.'),(10,'AA:Stacking','true','Allow AA that belong to the same group to stack on SOF+ clients.'),(10,'Console:SessionTimeOut','600000','Amount of time in ms for the console session to time out'),(10,'QueryServ:PlayerChatLogging','false','Logs Player Chat'),(10,'QueryServ:PlayerLogTrades','false','Logs Player Trades'),(10,'QueryServ:PlayerLogHandins','false','Logs Player Handins'),(10,'QueryServ:PlayerLogNPCKills','false','Logs Player NPC Kills'),(10,'QueryServ:PlayerLogDeletes','false','Logs Player Deletes'),(10,'QueryServ:PlayerLogMoves','false','Logs Player Moves'),(10,'QueryServ:MerchantLogTransactions','false','Logs Merchant Transactions'),(10,'QueryServ:PlayerLogPCCoordinates','false','Logs Player Coordinates with certain events'),(1,'Spells:CharismaCharmDuration','false','Allow CHA to extend charm duration.'),(1,'Spells:CharismaResistCap','255','Maximium amount of CHA that will effect charm resist rate.'),(1,'Inventory:EnforceAugmentRestriction','false','Forces augment slot restrictions.'),(1,'Inventory:EnforceAugmentUsability','false','Forces augmented item usability.'),(1,'Inventory:EnforceAugmentWear','false','Forces augment wear slot validation.'),(2,'Inventory:EnforceAugmentRestriction','false','Forces augment slot restrictions.'),(2,'Inventory:EnforceAugmentUsability','false','Forces augmented item usability.'),(2,'Inventory:EnforceAugmentWear','false','Forces augment wear slot validation.'),(4,'Inventory:EnforceAugmentRestriction','false','Forces augment slot restrictions.'),(4,'Inventory:EnforceAugmentUsability','false','Forces augmented item usability.'),(4,'Inventory:EnforceAugmentWear','false','Forces augment wear slot validation.'),(10,'Inventory:EnforceAugmentRestriction','false','Forces augment slot restrictions.'),(10,'Inventory:EnforceAugmentUsability','false','Forces augmented item usability.'),(10,'Inventory:EnforceAugmentWear','false','Forces augment wear slot validation.'),(1,'Spells:FearBreakCheckChance','70','Chance for fear to do a resist check each tick. Decrease for longer fears.'),(2,'Spells:FearBreakCheckChance','70','Chance for fear to do a resist check each tick. Decrease for longer fears.'),(4,'Spells:FearBreakCheckChance','70','Chance for fear to do a resist check each tick. Decrease for longer fears.'),(10,'Spells:FearBreakCheckChance','70','Chance for fear to do a resist check each tick. Decrease for longer fears.'),(10,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(1,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(2,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(4,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variables` (
  `varname` varchar(25) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `information` text NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`varname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `variables` VALUES ('AAXPMod','0.75','AA Experience multipler. Increase to increase exp rate','2010-09-06 15:03:51'),('ACfail','15','the percentage of time AC fails to protect. 0 would mean there was always some level of protection, 100 would mean AC has no affect. When AC fails, it will be possible to get a max dmg hit.','2010-09-06 15:03:51'),('ACrandom','20','','2010-09-06 15:03:51'),('ACreduction','3','','2010-09-06 15:03:51'),('ailevel','6','','2010-09-06 15:03:51'),('curInstFlagNum','2002','Determines what instance flag will be handed out next','2010-09-06 15:03:51'),('DBVersion','070_pop','DB version info','2010-09-06 15:03:51'),('decaytime 1 54','450','Corpse decay time for Level\'s 1 to 54','2010-09-06 15:03:51'),('decaytime 55 100','1800','Corpse decay time for Level\'s 55 to 100','2010-09-06 15:03:51'),('dfltInstZflag','1000','Used to determine if a zone is instanced, must be 1000 or greater','2010-09-06 15:03:51'),('disablecommandline','0','Allow command lines to be run from world.exe | 0 - off | 1 - on |','2010-09-06 15:03:51'),('Expansions','16383','Accessible expansions for each player','2010-09-06 15:03:51'),('EXPMod','0.75','Experience multipler. Increase to increase exp rate','2010-09-06 15:03:51'),('GroupEXPBonus','0.60','Experience multipler. Increase to increase group exp rate','2010-09-06 15:03:51'),('GuildWars','0','Enable Guild Wars Type Server | 0 - off | 1 - on |','2010-09-06 15:03:51'),('holdzones','0','Restart Crashed Zone Servers | 0 - off | 1 - on |','2010-09-06 15:03:51'),('leavecorpses','0','Players leave corpses | 0 - off | 1 - on |','2010-09-06 15:03:51'),('loglevel','0000','Commands,Merchants,Trades,Loot','2010-09-06 15:03:51'),('Max_AAXP','21626880','Max AA Experience','2010-09-06 15:03:51'),('MerchantsKeepItems','1','Merchants keep items sold to them | 0 - off | 1 - on |','2010-09-06 15:03:51'),('MOTD','Welcome to ProjectEQ! http://peqtgc.com Please use the forums to report bugs or other problems: http://www.peqtgc.com/phpBB3/ To activate a forum or login account, see the posts entitled \"Forum Activation\" and \"PEQ Login Server\" under the General section of the forums. We are setup to use the *ORIGINAL NEKTULOS* for Titanium/6.2 clients only Please see the forum post entitled \"About new zones\" also under the General section for further info.','','2010-09-06 15:05:08');
